<?php
$server="localhost";
$username="root";
$password="tiger";
$dbname="restaurant";
$connection=mysqli_connect($server,$username,$password,$dbname);

