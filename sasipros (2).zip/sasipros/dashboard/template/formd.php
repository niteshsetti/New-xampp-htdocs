<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
            shrink-to-fit=no">
    <title>Majestic Admin</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="images/favicon.png" />
    <script src="../../middleware/formd.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body onload="allhide()">
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                        <span class="mdi mdi-sort-variant"></span>
                    </button>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav mr-lg-4 w-100">
                    <li class="nav-item nav-search d-none d-lg-block w-100">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="search">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search">
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown me-1">
                        <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-message-text mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">David Grey
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        The meeting is cancelled
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">Tim Cook
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        New product launch
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal"> Johnson
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        Upcoming board meeting
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown me-4">
                        <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-success">
                                        <i class="mdi mdi-information mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Application Error</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Just now
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-warning">
                                        <i class="mdi mdi-settings mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Settings</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Private message
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-info">
                                        <i class="mdi mdi-account-box mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">New user registration</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        2 days ago
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="images/faces/face5.jpg" alt="profile" />
                            <span class="nav-profile-name">Louis Barnett</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">
                            <i class="mdi mdi-home menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inviteemp.html">
                            <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                            <span class="menu-title">Invite Employees</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
                            aria-controls="ui-basic">
                            <i class="mdi mdi-view-headline menu-icon"></i>
                            <span class="menu-title">Forms</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="ui-basic">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form
                                        A</a></li>
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form
                                        B</a></li>
                            </ul>
                        </div>
                    </li> -->


                    <li class="nav-item">
                        <a class="nav-link" href="emplist.html">
                            <i class="mdi mdi-grid-large menu-icon"></i>
                            <span class="menu-title">Employees List</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
                            <i class="mdi mdi-account menu-icon"></i>
                            <span class="menu-title">APPRAISAL</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="auth">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="appraisai.html"> Form A </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formb.html"> Form B </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formc.html"> Form C </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formd.html"> Form D</a></li>
                                <li class="nav-item"> <a class="nav-link" href="forme.html"> Form E </a></li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </nav>

            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">

                        <!--<div class="col-12 grid-margin stretch-card">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title">Basic form elements</h4>
                          <p class="card-description">
                            Basic form elements
                          </p>
                          <form class="forms-sample">
                            <div class="form-group">
                              <label for="exampleInputName1">Name</label>
                              <input type="text" class="form-control" id="exampleInputName1" placeholder="Name">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputEmail3">Email address</label>
                              <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Email">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputPassword4">Password</label>
                              <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                            </div>
                            <div class="form-group">
                              <label for="exampleSelectGender">Gender</label>
                              <select class="form-control" id="exampleSelectGender">
                                <option>Male</option>
                                <option>Female</option>
                              </select>
                            </div>
                            <div class="form-group">
                              <label>File upload</label>
                              <input type="file" name="img[]" class="file-upload-default">
                              <div class="input-group col-xs-12">
                                <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                                <span class="input-group-append">
                                  <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                </span>
                              </div>
                            </div>
                            <div class="form-group">
                              <label for="exampleInputCity1">City</label>
                              <input type="text" class="form-control" id="exampleInputCity1" placeholder="Location">
                            </div>
                            <div class="form-group">
                              <label for="exampleTextarea1">Textarea</label>
                              <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                          </form>
                        </div>
                      </div>
                    </div>-->
                        <div class="col-12 grid-margin">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">ADMINISTRATION
                                    </h4>
                                    <p class="card-description">
                                        (Details to be filled from 1-Jul-19 to 30-Jun-20)<br>
                                        Part A - For Compulsory Max Marks :150
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Pashow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th scope="col">S. No</th>
                                            <th width="60%">Designation & Responsibility</th>
                                            <th>Max Score</th>
                                            <th>Marks Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>CCO/Advisor/Principal / Dean / Director / COE/ Head HR</td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>Associate Dean/ Assistant COE/ University NIRF(Rankings) Chairman</td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>HOD</td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td>Alternate HOD / Deputy HOD/ RPAC/ University NCC coordinator</td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td>Responsible for any two tasks of highest value of enclosure-1 for this category: Specify with relevant proofs-<br>
                                                    a.

                                                    <br><br><br><br><br>
                                                    b.<br><br><br><br>



                                                </td>
                                                <td>150</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <hr>
                                    <div id="Padiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">S.No</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="snow" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Designation & Responsibility</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dr1">
                                                            <option selected hidden value="">Select your Designation & Responsibility</option>
                                                            <option value="capd">CCO/Advisor/Principal / Dean / Director / COE/ Head HR</option>
                                                            <option value="adac">Associate Dean/ Assistant COE/ University NIRF(Rankings) Chairman</option>
                                                            <option value="hod2">HOD</option>
                                                            <option value="ahdh">Alternate HOD / Deputy HOD/ RPAC/ University NCC coordinator</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label"> Max Score</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dr2">
                                                            <option selected hidden value="">Select Max Score</option>
                                                            <option value="dr2">150</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mkso" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasid1; ?>" id="sasid1">
                                                <button style="color: white;" class="btn btn-primary" onclick="formd1()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                    <p class="card-description">
                                        Part B - For Optional Extra 250 Marks:
                                    </p>
                                    <p class="card-description">
                                        Institutional Governance responsibilities
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Inshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="80%" scope="col">Nature of Activity</th>
                                            <th>Max Marks</th>
                                            <th>Marks Scored</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>CCO/Advisor/Principal / Dean / Director / COE/ Head HR<br>
                                                    Achievements:<br>
                                                    <br><br><br><br><br><br><br>
                                                </td>
                                                <td>250</td>
                                            </tr>
                                            <tr>
                                                <td>Associate Dean/ Assistant COE <br>
                                                    Achievements:<br><br><br><br><br><br><br>
                                                </td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td>HOD<br>Achievements:<br><br><br><br><br><br><br><br></td>
                                                <td>200</td>
                                            </tr>
                                            <tr>
                                                <td>Alternate HOD / Deputy HOD/ RPAC/ University NCC coordinator</td>
                                                <td>150</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" align="right">Total Marks Obtained
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <br>
                                    <hr>
                                    <div id="Indiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Name of the Activity</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dr3">
                                                            <option selected hidden value="">Select your Activity</option>
                                                            <option value="capd">CCO/Advisor/Principal / Dean / Director / COE/ Head HR</option>
                                                            <option value="adac">Associate Dean/ Assistant COE</option>
                                                            <option value="hod2">HOD</option>
                                                            <option value="ahdh">Alternate HOD / Deputy HOD/ RPAC/ University NCC coordinator</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Max Marks</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dr4">
                                                            <option selected hidden value="">Select Max Marks</option>
                                                            <option value="capd">250</option>
                                                            <option value="adac">150</option>
                                                            <option value="hod2">200</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks Scored</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mksc" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <div class="col-md-6">
                                                        <div class="form-group row">
                                                            <input type="hidden" value="<?php echo $sasid2; ?>" id="sasid2">
                                                            <button style="color: white;" class="btn btn-primary" onclick="formd2()" id="hide">Insert</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">Project Expo.com </a>2022</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <script>
        $(document).ready(function() {

            $("#Pashow").click(function() {
                $("#Padiv").toggle();
            });
            $("#Inshow").click(function() {
                $("#Indiv").toggle();
            });

        });
    </script>
    <script>
        function allhide() {


            document.getElementById('Padiv').style.display = "none";
            document.getElementById('Indiv').style.display = "none";
        }
    </script>
    <!-- plugins:js -->
    <script src="vendors/base/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="vendors/chart.js/Chart.min.js"></script>
    <script src="vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/hoverable-collapse.js"></script>
    <script src="js/template.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="js/dashboard.js"></script>
    <script src="js/data-table.js"></script>
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap4.js"></script>
    <!-- End custom js for this page-->

    <script src="js/jquery.cookie.js" type="text/javascript"></script>
</body>

</html>