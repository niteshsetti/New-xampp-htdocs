function tla(a4,b4,c4,d4,e4,f4,g4,h4,i4,j4,k4) {
    document.getElementById("a4").value = a4;
    document.getElementById("b4").value = b4;
    document.getElementById("c4").value = c4;
    document.getElementById("d4").value = d4;
    document.getElementById("e4").value = e4;
    document.getElementById("f4").value = f4;
    document.getElementById("g4").value = g4;
    document.getElementById("h4").value = h4;
    document.getElementById("i4").value = i4;
    document.getElementById("j4").value = j4;
    document.getElementById("k4").value = k4;
}




$(document).ready(function () {
    $("#uformb1").click(function () {
        var a4 = document.getElementById("a4").value;
        var b4 = document.getElementById("b4").value;
        var c4 = document.getElementById("c4").value;
        var d4 = document.getElementById("d4").value;
        var e4 = document.getElementById("e4").value;
        var f4 = document.getElementById("f4").value;
        var g4 = document.getElementById("g4").value;
        var h4=  document.getElementById("h4").value;
        var i4 = document.getElementById("i4").value;
        var j4 = document.getElementById("j4").value;
        var k4 = document.getElementById("k4").value;
        $.ajax({
            url: "../backend/updateformb.php",
            method: "post",
            async: false,
            data: {
                "a4": a4,
                "b4": b4,
                "c4": c4,
                "d4": d4,
                "e4": e4,
                "f4": f4,
                "g4": g4,
                "h4": h4,
                "i4": i4,
                "j4": j4,
                "k4": k4


            },
            success: function (data) {
                console.log(data);
                if (data === "Success") {
                   setTimeout(function () {
                        window.location.replace("404");
                    });
                }
            }
        })
    });

    
});
