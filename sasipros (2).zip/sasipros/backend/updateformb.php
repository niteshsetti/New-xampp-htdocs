<?php
include '../backend/db.php';
if(isset($_POST["a4"]) || isset($_POST["b4"]) ||isset($_POST["c4"]) ||isset($_POST["d4"]) ||isset($_POST["e4"]) || isset($_POST["f4"]) || isset($_POST["g4"]) ||isset($_POST["h4"]) ||isset($_POST["i4"]) ||isset($_POST["j4"]) ||isset($_POST["k4"]))
{
    $a4=$_POST["a4"];
    $b4=$_POST["b4"];
    $c4=$_POST["c4"];
    $d4=$_POST["d4"];
    $e4=$_POST["e4"];
    $f4=$_POST["f4"];
    $g4=$_POST["g4"];
    $h4=$_POST["h4"];
    $i4=$_POST["i4"];
    $j4=$_POST["j4"];
    $k4=$_POST["k4"];
    
    $sql="update teachinglearningevaluation set CC='$a4',CN='$b4',Bran='$c4',Yea='$d4',Semi='$e4',
    Sec='$f4', Nosp='$g4',Nosd='$h4',Per='$i4',MS='$j4' where Param='$k4'";
   $exe=mysqli_query($connection,$sql);
   if($sql)
   {
       echo "Success";
   }
   else
   {
       echo "Failed";
   }
}



?>
