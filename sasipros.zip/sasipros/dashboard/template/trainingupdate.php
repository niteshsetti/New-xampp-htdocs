<?php
session_start();
include '../../backend/dashcount.php';
include '../../backend/db.php';
$quaid=$_GET["paramterconfigauth"];
$email = $_SESSION["email"];
@$name = $_SESSION["name"];
$details_of_emp = "select *from training where Param='$quaid'";
$execute_query = mysqli_query($connection, $details_of_emp);
$details_row = mysqli_fetch_array($execute_query);
@$emp_deg = $details_row['Pfrom'];
@$emp_uni = $details_row['Pto'];
@$emp_coll = $details_row['Tper'];
@$emp_stat = $details_row['Nop'];
@$emp_clas = $details_row['Institution'];
@$emp_yop = $details_row['Remarks'];
@$emp_params=$details_row['Param']
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Majestic Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="../../middleware/updateall.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body onload="allhide()">
  <?php
  if ($email == "admin@gmail.com") {
  ?>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex justify-content-center">
          <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
            <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
            <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="mdi mdi-sort-variant"></span>
            </button>
          </div>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                <img src="images/faces/face5.jpg" alt="profile" />
                <span class="nav-profile-name">Admin</span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="sasiboard">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inviteemp">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Invite Employees</span>
              </a>
            </li>
            <!-- <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
              aria-controls="ui-basic">
              <i class="mdi mdi-view-headline menu-icon"></i>
              <span class="menu-title">Forms</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form A</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form B</a></li>
              </ul>
            </div>
          </li> -->


            <li class="nav-item">
              <a class="nav-link" href="emplist">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Employees List</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="appraisai">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">APPRAISAL</span>
              </a>
            </li>

          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between flex-wrap">
                  <div class="d-flex align-items-end flex-wrap">
                    <div class="me-md-3 me-xl-5">
                      <h2>SITE APPRAISAL PORTAL</h2>
                      <p class="mb-md-0">Welcome Admin,</p>
                    </div>
                    <div class="d-flex">
                      <i class="mdi mdi-home text-muted hover-cursor"></i>
                      <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;</p>
                      <p class="text-primary mb-0 hover-cursor">Analytics</p>
                    </div>
                  </div>
                  <div class="d-flex justify-content-between align-items-end flex-wrap">

                    <a href="#" style="color: white;" class="btn btn-primary mt-2 mt-xl-0">Invite Employee</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body dashboard-tabs p-0">
                    <ul class="nav nav-tabs px-4" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="overview-tab" data-bs-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
                      </li>
                    </ul>
                    <div class="tab-content py-0 px-0">
                      <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                        <div class="d-flex flex-wrap justify-content-xl-between">
                          <div class="d-none d-xl-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-account-plus icon-lg me-3 text-primary"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Total Employee Invited</small>
                              <div class="dropdown">
                                <a class="btn btn-secondary p-0 bg-transparent border-0 text-dark shadow-none font-weight-medium" href="#" role="button">
                                  <h5 class="mb-0 d-inline-block" id="msg"></h5>
                                </a>

                              </div>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-account-arrow-right me-3 icon-lg text-success"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Employees Registered</small>
                              <h5 class="me-2 mb-0" id="msg1"></h5>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-contact-mail me-3 icon-lg text-success"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Total Mails Sent</small>
                              <h5 class="me-2 mb-0" id="msg2"></h5>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-download me-3 icon-lg text-warning"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">APPRAISAL</small>
                              <h5 class="me-2 mb-0">0</h5>
                            </div>
                          </div>

                        </div>
                      </div>


                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">SASI APPRAISAL</a>2022</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  <?php
  } else {
  ?>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex justify-content-center">
          <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
            <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
            <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="mdi mdi-sort-variant"></span>
            </button>
          </div>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                <img src="images/faces/face5.jpg" alt="profile" />
                <span class="nav-profile-name"><?php echo $email; ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="sasiboard">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Profile</span>
              </a>
            </li>
            <!-- <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
              aria-controls="ui-basic">
              <i class="mdi mdi-view-headline menu-icon"></i>
              <span class="menu-title">Forms</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form A</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form B</a></li>
              </ul>
            </div>
          </li> -->


            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Forms</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">APPRAISAL</span>
              </a>
            </li>

          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between flex-wrap">
                  <div class="d-flex align-items-end flex-wrap">
                    <div class="me-md-3 me-xl-5">
                      <h2>SITE APPRAISAL PORTAL</h2>
                      <p class="mb-md-0">Welcome <?php echo $name; ?>,</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Your Training Information</h4>
                    <div class="text-end">
                      <svg id="update1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 172 172" style=" fill:#000000;">
                        <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                          <path d="M0,172v-172h172v172z" fill="none"></path>
                          <path d="M0,172v-172h172v172z" fill="#cccccc"></path>
                          <g fill="#000000">
                            <path d="M123.4907,27.9502c-1.46701,0 -2.93563,0.55882 -4.05363,1.67968l-9.78694,9.78694l22.93325,22.93325l9.78694,-9.78694c2.24173,-2.24173 2.24173,-5.87127 0,-8.10726l-14.82598,-14.82599c-1.12086,-1.12086 -2.58662,-1.67968 -4.05364,-1.67968zM101.05016,48.01679l-65.93309,65.93309v22.93325h22.93325l65.93309,-65.93309z"></path>
                          </g>
                        </g>
                      </svg>
                    </div>
                    <p class="card-description">
                      Personal Training Updation
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Period From</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" value="<?php echo $emp_deg; ?>" id="updeg" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Period To</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" value="<?php echo $emp_uni; ?>" id="upuni" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Total Period of Training</label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control" value="<?php echo $emp_coll; ?>" id="upcoll" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nature of Program</label>
                          <div class="col-sm-9">
                            <input class="form-control" type="text" value="<?php echo $emp_stat; ?>" id="upstat" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Institution</label>
                          <div class="col-sm-9">
                          <input type="text" class="form-control" value="<?php echo $emp_clas; ?>" id="upclas" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Remarks</label>
                          <div class="col-sm-9">
                            <input class="form-control" type="text" value="<?php echo $emp_yop; ?>" id="upyop" />
                          </div>
                        </div>
                      </div>
                    </div>
                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group row">
                            <input type="hidden" value="<?php echo $emp_params; ?>" id="quapar">
                            <button style="color: white;" class="btn btn-primary" onclick="updatetraining()" id="hide">Update</button>
                          </div>
                        </div>
                      </div>
                  </div>
            </div>
          </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">SASI APPRAISAL</a>2022</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  <?php
  }
  ?>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/data-table.js"></script>
  <script src="js/jquery.dataTables.js"></script>
  <script src="js/dataTables.bootstrap4.js"></script>
  <!-- End custom js for this page-->

  <script src="js/jquery.cookie.js" type="text/javascript"></script>
  <script>
    $("#hide").hide();
    $('#updeg,#upuni,#upcoll,#upstat,#upclas,#upyop').attr('readonly', true);
    $(document).ready(function() {
      $("#update1").click(function() {
        $("#hide").show();
        $('#updeg,#upuni,#upcoll,#upstat,#upclas,#upyop').attr('readonly', false);
      });
    });
  </script>
</body>

</html>