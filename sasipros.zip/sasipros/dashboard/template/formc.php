<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
            shrink-to-fit=no">
    <title>Majestic Admin</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="images/favicon.png" />
    <script src="../../middleware/formc.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body onload="allhide()">
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                        <span class="mdi mdi-sort-variant"></span>
                    </button>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav mr-lg-4 w-100">
                    <li class="nav-item nav-search d-none d-lg-block w-100">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="search">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search">
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown me-1">
                        <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-message-text mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">David Grey
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        The meeting is cancelled
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">Tim Cook
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        New product launch
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal"> Johnson
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        Upcoming board meeting
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown me-4">
                        <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-success">
                                        <i class="mdi mdi-information mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Application Error</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Just now
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-warning">
                                        <i class="mdi mdi-settings mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Settings</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Private message
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-info">
                                        <i class="mdi mdi-account-box mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">New user registration</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        2 days ago
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="images/faces/face5.jpg" alt="profile" />
                            <span class="nav-profile-name">Louis Barnett</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">
                            <i class="mdi mdi-home menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inviteemp.html">
                            <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                            <span class="menu-title">Invite Employees</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
                            aria-controls="ui-basic">
                            <i class="mdi mdi-view-headline menu-icon"></i>
                            <span class="menu-title">Forms</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="ui-basic">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form
                                        A</a></li>
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form
                                        B</a></li>
                            </ul>
                        </div>
                    </li> -->


                    <li class="nav-item">
                        <a class="nav-link" href="emplist.html">
                            <i class="mdi mdi-grid-large menu-icon"></i>
                            <span class="menu-title">Employees List</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
                            <i class="mdi mdi-account menu-icon"></i>
                            <span class="menu-title">APPRAISAL</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="auth">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="appraisai.html"> Form A </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formb.html"> Form B </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formc.html"> Form C </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formd.html"> Form D</a></li>
                                <li class="nav-item"> <a class="nav-link" href="forme.html"> Form E </a></li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </nav>

            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">

                        <!--<div class="col-12 grid-margin stretch-card">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title">Basic form elements</h4>
                          <p class="card-description">
                            Basic form elements
                          </p>
                          <form class="forms-sample">
                            <div class="form-group">
                              <label for="exampleInputName1">Name</label>
                              <input type="text" class="form-control" id="exampleInputName1" placeholder="Name">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputEmail3">Email address</label>
                              <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Email">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputPassword4">Password</label>
                              <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                            </div>
                            <div class="form-group">
                              <label for="exampleSelectGender">Gender</label>
                              <select class="form-control" id="exampleSelectGender">
                                <option>Male</option>
                                <option>Female</option>
                              </select>
                            </div>
                            <div class="form-group">
                              <label>File upload</label>
                              <input type="file" name="img[]" class="file-upload-default">
                              <div class="input-group col-xs-12">
                                <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                                <span class="input-group-append">
                                  <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                </span>
                              </div>
                            </div>
                            <div class="form-group">
                              <label for="exampleInputCity1">City</label>
                              <input type="text" class="form-control" id="exampleInputCity1" placeholder="Location">
                            </div>
                            <div class="form-group">
                              <label for="exampleTextarea1">Textarea</label>
                              <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                          </form>
                        </div>
                      </div>
                    </div>-->
                        <div class="col-12 grid-margin">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">RESEARCH AND ALLIED CONTRIBUTIONS (Proofs to be attached only for Assessment period)
                                        (Details to be filled from 1-Jan-19 to 31-Dec-19)
                                    </h4>

                                    <p class="card-description">
                                        Part A - For Compulsory Max Marks :150<br>
                                        Sl. No. 1 and 2 are mandatory and 3 to 5 are capped to 50 Marks
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Pashow">Add</a></p>
                                    </p>
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>S. No</th>
                                                <th width="40%">Nature of Activity</th>
                                                <th>Marks</th>
                                                <th>Number</th>
                                                <th>Marks Obtained</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Journal Publications- Scopus/WOS/IIM indexed
                                                    Assistant Professor- 2, Associate Professor - 3,
                                                    Professor - 4
                                                    (Max 80 and Proportionate)
                                                    Ex: If Asst Prof Publish only one paper, eligible to get 40 Max)
                                                </td>
                                                <td>80(MAX)</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>Citations in the assessing period- 5 per citation</td>
                                                <td>20 (MAX)</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>Organising Research related course / Workshops/ National / International Conference / Symposiums</td>
                                                <td>10 per activity</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td>Papers Presented / Participated in International conference</td>
                                                <td>10 per paper</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td>Papers Presented / Participated in National Level conference.</td>
                                                <td>5 per activity</td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div id="Padiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Nature of Activity</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top">
                                                            <option selected hidden value="">Select Marks </option>
                                                            <option value="jpsw">Journal Publications- Scopus/WOS/IIM indexed Assistant Professor- 2, Associate Professor - 3, Professor - 4 (Max 80 and Proportionate) Ex: If Asst Prof Publish only one paper, eligible to get 40 Max)</option>
                                                            <option value="cita">Citations in the assessing period- 5 per citation</option>
                                                            <option value="orrc">Organising Research related course / Workshops/ National / International Conference / Symposiums</option>
                                                            <option value="pppi">Papers Presented / Participated in International conference</option>
                                                            <option value="ppin">Papers Presented / Participated in National Level conference.</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top1">
                                                            <option selected hidden value="">Select Nature of Activity </option>
                                                            <option value="max8">80(MAX)</option>
                                                            <option value="max2">20 (MAX)</option>
                                                            <option value="pa10">10 per activity</option>
                                                            <option value="pp10">10 per paper</option>
                                                            <option value="pac5">5 per activity</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Number</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="numb" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="maob" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid1; ?>" id="sasiid1">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc1()" id="hide">Insert</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <br>
                                <p class="card-description">
                                    Part B - For Optional Extra 250 Marks:
                                    (provide data other than mentioned in Part A)
                                <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Opshow">Add</a></p>

                                </p>
                                <table width="100%">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th width="60%">
                                                <center>Nature of Activity</center>
                                            </th>
                                            <th rowspan="2">No. of papers Published</th>
                                            <th rowspan="2">Max Score per Publications</th>
                                            <th rowspan="2">Marks Obtained</th>
                                        </tr>
                                        <tr>
                                            <th>1</th>
                                            <th>
                                                <center>Research Publications (Journals)</center>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <td colspan="4" style="text-align:right">
                                            <hr>Total Score Achieved
                                        </td>
                                    </tbody>
                                </table>
                                <div id="Opdiv">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Nature of Activity Research Publications (Journals)</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="a2" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">No. of papers Published</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="b2" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Max Score per Publications</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="c2" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="d2" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasiid; ?>" id="e2">
                                                <button style="color:white;" class="btn btn-primary" onclick="formc2()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <small style="font-size: 10px;">Single Author---100% weightage, Two Authors-First Author-60% and Second Author-40% weightage
                                    Three Authors-First Author-50%,Second Author-30%,Third Author-20% weightage
                                    Four Authors – First Author – 50%, Second Author – 30%, Third Author – 10%, Fourth Author – 10%
                                    Marks obtained = Number of papers published * Score per paper.
                                </small>
                                <br>
                                <hr>
                                <p class="card-description">
                                    Impact factor is to be issued only by Thomson Reuters (Clarivate Analytics).
                                </p>
                                <p class="card-description">
                                    Citation Index
                                <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Cishow">Add</a></p>
                                </p>
                                <table width="100%">
                                    <thead>

                                        <tr>
                                            <th>Research Publications (Journals)</th>
                                            <th>Marks</th>
                                            <th>Marks Obtained</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>No. of citations in the assessing period</td>
                                            <td>5 per each cross citation - upto Max. 150 marks</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>h- index</td>
                                            <td>(upto 5 - 25 Marks, beyond 5 - 50 Marks) </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>i10 index</td>
                                            <td>5 per each i10 index value </td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" style="text-align:right">
                                                <hr>Total Score Achieved
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div id="Cidiv">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Research Publications (Journals) No. of citations in the assessing period h- index i10 index</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="rpj" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks 5 per each cross citation - upto Max. 150 marks 5 per each i10 index value</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="mfpe" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="mar2" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasiid3; ?>" id="sasiid3">
                                                <button style="color: white;" class="btn btn-primary" onclick="formc3()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <br>
                                <p class="card-description">
                                    Book Publications (books, in chapters in books, other than referred journal articles)
                                <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Boshow">Add</a></p>
                                </p>
                                <table width="100%">
                                    <thead>
                                        <th width="50%">Type of Publications</th>
                                        <th>No. Published</th>
                                        <th>Marks per Publication</th>
                                        <th>Marks Achieved</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Text or reference Books Published by International Publishers with an established peer review system</td>
                                            <td></td>
                                            <td>50</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Chapters in edited books Published by International Publishers with an established peer review system</td>
                                            <td></td>
                                            <td>20</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Subjects Books by National level publishers /State and Central Govt. level with ISBN/ISSN numbers</td>
                                            <td></td>
                                            <td>30</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>Chapters in edited books by National level publishers /State and Central Govt. level with ISBN/ISSN numbers</td>
                                            <td></td>
                                            <td>15</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" align="right">
                                                <hr>Total Marks Achieved
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div id="Bodiv">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Type of Publications</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control form-control-sm" id="topp1">
                                                        <option selected hidden value="">Select Type of Publications </option>
                                                        <option value="tor">Text or reference Books Published by International Publishers with an established peer review system</option>
                                                        <option value="cie">Chapters in edited books Published by International Publishers with an established peer review system</option>
                                                        <option value="sbb">Subjects Books by National level publishers /State and Central Govt. level with ISBN/ISSN numbers</option>
                                                        <option value="cieb">Chapters in edited books by National level publishers /State and Central Govt. level with ISBN/ISSN numbers</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">No. Published</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="np" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks per Publication</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control form-control-sm" id="mppo1">
                                                        <option selected hidden value="">Select Marks</option>
                                                        <option value="fif">50</option>
                                                        <option value="twe">20</option>
                                                        <option value="thi">30</option>
                                                        <option value="fift">15</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks Acheived</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="mar3" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasiid4; ?>" id="sasiid4">
                                                <button style="color: white;" class="btn btn-primary" onclick="formc4()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <br>
                                <p class="card-description">
                                    Research Project - Sponsored Projects carried out/ ongoing
                                <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Reshow">Add</a></p>
                                </p>
                                <table width="100%">
                                    <thead>
                                        <th width="50%">Type of Project</th>
                                        <th>No of Project</th>
                                        <th>Score per Project</th>
                                        <th>Mark Obtained</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Major Projects amount mobilized with grants above Rupees 1 crore in India & abroad</td>
                                            <td></td>
                                            <td>50</td>
                                        </tr>
                                        <tr>
                                            <td>Major Projects amount mobilized with grants above Rupees 30.00 lakhs up to 1 crore in India & abroad</td>
                                            <td></td>
                                            <td>35</td>
                                        </tr>
                                        <tr>
                                            <td>Major Projects amount mobilized with grants above Rupees 5.0 lakhs up to 30.00 lakhs in India & abroad</td>
                                            <td></td>
                                            <td>25</td>
                                        </tr>
                                        <tr>
                                            <td>Minor Projects from central / state funding agencies with grants below Rs.5.00 lakhs in India & abroad</td>
                                            <td></td>
                                            <td>20</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" align="right">Total Marks Achieved</td>
                                        </tr>

                                    </tbody>
                                </table>
                                <div id="Rediv">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Type of Project</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control form-control-sm" id="top2">
                                                        <option selected hidden value="">Type of Project </option>
                                                        <option value="mpa1">Major Projects amount mobilized with grants above Rupees 1 crore in India & abroad</option>
                                                        <option value="mpa2">Major Projects amount mobilized with grants above Rupees 30.00 lakhs up to 1 crore in India & abroad</option>
                                                        <option value="mpa3">Major Projects amount mobilized with grants above Rupees 5.0 lakhs up to 30.00 lakhs in India & abroad</option>
                                                        <option value="mpf">Minor Projects from central / state funding agencies with grants below Rs.5.00 lakhs in India & abroad</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">No of Project</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="nop2" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Score per Project</label>
                                                <div class="col-sm-9">
                                                    <select class="form-control form-control-sm" id="top3">
                                                        <option selected hidden value="">Select score per Project </option>
                                                        <option value="fifty">50</option>
                                                        <option value="thif">35</option>
                                                        <option value="twef">25</option>
                                                        <option value="twenty">20</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-sm-3 col-form-label">Marks Acheived</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" id="mar4" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasiid5; ?>" id="sasiid5">
                                                <button style="color: white;" class="btn btn-primary" onclick="formc5()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <br>
                                    <p class="card-description">
                                        Sponsored Projects
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Spshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%">Type of project</th>
                                            <th>No. Of Projects</th>
                                            <th>Marks per Project</th>
                                            <th>Mark Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Major projects completed project Reports (Acceptance from funding agency ) beyond 5 lakhs
                                                </td>
                                                <td></td>
                                                <td>40</td>
                                            </tr>
                                            <tr>
                                                <td>Minor projects completed project Reports (Acceptance from funding agency ) below 5 lakhs
                                                </td>
                                                <td></td>
                                                <td>20</td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" align="right">Total Marks Achieved</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Spdiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Type of Project</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top4">
                                                            <option selected hidden value="">Selct Type of Project </option>
                                                            <option value="mpa1">Major projects completed project Reports (Acceptance from funding agency ) beyond 5 lakhs</option>
                                                            <option value="mpa2">Minor projects completed project Reports (Acceptance from funding agency ) below 5 lakhs</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">No. Of Projects</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="nop3" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks per Project</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="mpp">
                                                            <option selected hidden value="">Select Marks per project</option>
                                                            <option value="four">40</option>
                                                            <option value="to">20<s /option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Mark Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mar5" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid6; ?>" id="sasiid6">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc6()" id="hide">Insert</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <hr>
                                    <p class="card-description">
                                        Patents
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Peshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%">Type of Patents</th>
                                            <th>No. Of Patents</th>
                                            <th>Marks per Patents</th>
                                            <th>Mark Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>No. of patents filed/published
                                                </td>
                                                <td></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>National Patent/Technology transfer / Product/ Process
                                                    (Granted)
                                                </td>
                                                <td></td>
                                                <td>30</td>
                                            </tr>
                                            <tr>
                                                <td>International Patent/Technology transfer / Product/ Process
                                                    (Granted)
                                                </td>
                                                <td></td>
                                                <td>50</td>
                                            </tr>
                                            <tr>
                                                <td colspan="3" align="right">Total Marks Achieved</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Pediv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Type of Patents</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top5">
                                                            <option selected hidden value="">Select type of patents</option>
                                                            <option value="nopf">No. of patents filed/published</option>
                                                            <option value="nptt">National Patent/Technology transfer / Product/ Process (Granted)</option>
                                                            <option value="ipt1">International Patent/Technology transfer / Product/ Process (Granted)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label"> No. Of Patents</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="nop4" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks per Patents</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="mpp1">
                                                            <option selected hidden value="">Select Marks Per Patents</option>
                                                            <option value="four">40</option>
                                                            <option value="to">20<s /option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Mark Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mar6" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid7; ?>" id="sasiid7">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc7()" id="hide">Insert</button>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                    <hr>
                                    <br>
                                    <p class="card-description">
                                        Guidance
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Gushow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%" colspan="2">Type of Project</th>
                                            <th>No. Guided</th>
                                            <th>Marks per Project</th>
                                            <th>Mark Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Ph.D Doctoral Projects
                                                </td>
                                                <td>Degree awarded No.</td>
                                                <td>1</td>
                                                <td>15</td>
                                                <td>15</td>
                                            </tr>

                                            <tr>
                                                <td colspan="4" align="right">Total Marks Achieved</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Gudiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Type of Project</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top6">
                                                            <option selected hidden value="">Select type of project</option>
                                                            <option value="nopf">Ph.D Doctoral Projects</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Degree awarded No.</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="dan" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">No. Guided</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="ng" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks per Project</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mpp2" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Mark Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mar7" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <input type="hidden" value="<?php echo $sasiid8; ?>" id="sasiid8">
                                                <button style="color: white;" class="btn btn-primary" onclick="formc8()" id="hide">Insert</button>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <br>
                                    <p class="card-description">
                                        Awards - Honors/ Recognitions
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Awshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%">Type of awards</th>
                                            <th>No. of awards</th>
                                            <th>Marks per award</th>
                                            <th>Mark Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Awards by Foreign universities / Accredited International Bodies (approved by NBA/NAAC/AICTE..etc)
                                                </td>
                                                <td></td>
                                                <td>20</td>

                                            </tr>
                                            <tr>
                                                <td>National: by UGC, CSIR, DST & other Government bodies and professional Academies like Bhatnagar Award etc., .
                                                </td>
                                                <td></td>
                                                <td>15</td>

                                            </tr>
                                            <tr>
                                                <td>State/university level.(approved by NBA/NAAC/AICTE..etc)
                                                </td>
                                                <td></td>
                                                <td>10</td>

                                            </tr>
                                            <tr>
                                                <td>Regional / local.(approved by NBA/NAAC/AICTE..etc)
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>

                                            <tr>
                                                <td colspan="3" align="right">Total Marks Achieved</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Awdiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Type of awards</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top77">
                                                            <option selected hidden value="">Select type of awards</option>
                                                            <option value="abf">Awards by Foreign universities / Accredited International Bodies (approved by NBA/NAAC/AICTE..etc)</option>
                                                            <option value="nbu">National: by UGC, CSIR, DST & other Government bodies and professional Academies like Bhatnagar Award etc., .</option>
                                                            <option value="sul">State/university level.(approved by NBA/NAAC/AICTE..etc)</option>
                                                            <option value="rl">Regional / local.(approved by NBA/NAAC/AICTE..etc)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">No. of awards</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="noa17" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks per award</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="top87">
                                                            <option selected hidden value="">Select marks per award</option>
                                                            <option value="twelv">20</option>
                                                            <option value="fifte">15</option>
                                                            <option value="teen">10</option>
                                                            <option value="fove">5</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="mar87" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid9; ?>" id="sasiid97">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc9()" id="hide">Insert</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <br>
                                    <p class="card-description">
                                        Post- Doctoral Degrees
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Poshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%">Type of Achievement</th>
                                            <th>Marks per Achievement</th>
                                            <th>Mark Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Ph.D
                                                </td>
                                                <td>10</td>
                                                <td></td>

                                            </tr>
                                            <tr>
                                                <td>D.Sc/PDF
                                                </td>
                                                <td>10</td>
                                                <td></td>

                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Podiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Type of Achievement</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="a">
                                                            <option selected hidden value="">Select Type of Achievement</option>
                                                            <option value="phd">Ph.D</option>
                                                            <option value="dsc">D.Sc/PDF</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks per Achievement</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="b">
                                                            <option selected hidden value="">Select marks per acheivement</option>
                                                            <option value="phd10">10</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Mark Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="c" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid10; ?>" id="d">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc10()" id="hide">Insert</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <hr>
                                    <p class="card-description">
                                        Other activities
                                    <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Otshow">Add</a></p>
                                    </p>
                                    <table width="100%">
                                        <thead>
                                            <th width="50%">Details</th>
                                            <th>No. Activities</th>
                                            <th>Max Marks</th>
                                            <th>Marks Obtained</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Guest lectures delivered – national/international national
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Collaborations – Foreign Universities/IITs/NITs/Others
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Innovation & Incubation – startups regd
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Innovation & Incubation – applied for funding
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Innovation & Incubation – prototype ready
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Innovation & Incubation – scale up activities
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Corporate training
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Research community connect-Orcid/Publons/Google/RG/Microsoft
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Membership in professional bodies
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td>Outreach/ extension programs with Industry/NGO/others
                                                </td>
                                                <td></td>
                                                <td>5</td>

                                            </tr>
                                            <tr>
                                                <td colspan="3" align="right">Total Marks Achieved</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                    <div id="Otdiv">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Other Activities</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="a1">
                                                            <option selected hidden value="">Select your activity</option>
                                                            <option value="phd">Guest lectures delivered - national/international national</option>
                                                            <option value="dsc">Collaborations - Foreign Universities/IITs/NITs/Others</option>
                                                            <option value="dsc">Innovation & Incubation - startups regd</option>
                                                            <option value="dsc">Innovation & Incubation - applied for funding</option>
                                                            <option value="dsc">Innovation & Incubation - prototype ready</option>
                                                            <option value="dsc">Innovation & Incubation - scale up activities</option>
                                                            <option value="dsc">Corporate training</option>
                                                            <option value="dsc">Research community connect-Orcid/Publons/Google/RG/Microsoft</option>
                                                            <option value="dsc">Membership in professional bodies</option>
                                                            <option value="dsc">Outreach/ extension programs with Industry/NGO/others</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">No. Activities</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="b1" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Max Marks</label>
                                                    <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="c1">
                                                            <option selected hidden value="">Enter Max Marks</option>
                                                            <option value="five1">5</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="d1" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <input type="hidden" value="<?php echo $sasiid11; ?>" id="e1">
                                                    <button style="color: white;" class="btn btn-primary" onclick="formc11()" id="hide">Insert</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <br>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">Project Expo.com </a>2022</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <script>
        $(document).ready(function() {

            $("#Pashow").click(function() {
                $("#Padiv").toggle();
            });
            $("#Opshow").click(function() {
                $("#Opdiv").toggle();
            });
            $("#Cishow").click(function() {
                $("#Cidiv").toggle();
            });
            $("#Boshow").click(function() {
                $("#Bodiv").toggle();
            });
            $("#Reshow").click(function() {
                $("#Rediv").toggle();
            });
            $("#Spshow").click(function() {
                $("#Spdiv").toggle();
            });
            $("#Peshow").click(function() {
                $("#Pediv").toggle();
            });
            $("#Gushow").click(function() {
                $("#Gudiv").toggle();
            });
            $("#Awshow").click(function() {
                $("#Awdiv").toggle();
            });
            $("#Poshow").click(function() {
                $("#Podiv").toggle();
            });
            $("#Otshow").click(function() {
                $("#Otdiv").toggle();
            });
        });
    </script>
    <script>
        function allhide() {


            document.getElementById('Padiv').style.display = "none";
            document.getElementById('Opdiv').style.display = "none";
            document.getElementById('Cidiv').style.display = "none";
            document.getElementById('Bodiv').style.display = "none";
            document.getElementById('Rediv').style.display = "none";
            document.getElementById('Spdiv').style.display = "none";
            document.getElementById('Pediv').style.display = "none";
            document.getElementById('Gudiv').style.display = "none";
            document.getElementById('Awdiv').style.display = "none";
            document.getElementById('Podiv').style.display = "none";
            document.getElementById('Otdiv').style.display = "none";

        }
    </script>
    <!-- plugins:js -->
    <script src="vendors/base/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="vendors/chart.js/Chart.min.js"></script>
    <script src="vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/hoverable-collapse.js"></script>
    <script src="js/template.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="js/dashboard.js"></script>
    <script src="js/data-table.js"></script>
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap4.js"></script>
    <!-- End custom js for this page-->

    <script src="js/jquery.cookie.js" type="text/javascript"></script>
</body>

</html>