<?php
$server="localhost";
$username="root";
$password="tiger";
$dbname="sasi";
$connection=mysqli_connect($server,$username,$password,$dbname);
?>