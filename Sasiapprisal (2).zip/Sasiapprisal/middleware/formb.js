const formb=()=>{
    var cc = document.getElementById("cc").value;
    var cn = document.getElementById("cn").value;
    var bra = document.getElementById("bra").value;
    var year = document.getElementById("year").value;
    var sem = document.getElementById("sem").value;
    var sec = document.getElementById("sec").value;
    var nosp = document.getElementById("nosp").value;
    var nosd = document.getElementById("nosd").value;
    var per = document.getElementById("per").value;
    var ms = document.getElementById("ms").value;
    var sasiid4=document.getElementById("sasiid4").value;
    if (cc == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcecode',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (cn == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Cource name',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (bra == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Branch',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (year == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (sem == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (sec == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (nosp == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (nosd == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (per == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else if (ms == "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Enter Your Courcename',
            confirmButtonColor: 'blue',
            showConfirmButton: false,
            timer: 1500
        })
    }
    else{
        $.ajax({
            url:"",
            method:"post",
            async:false,
            data:{
            "cc":cc,
            "cn":cn,
            "branch":bra,
            "year":year,
            "sem":sem,
            "sec":sec,
            "nosd":nosd,
            "nosp":nosp,
            "per":per,
            "ms":ms,
            "sasiid":sasiid4
            },
            success:function(data)
            {

            }
        });
    }
}

const formb2=()=>{

}