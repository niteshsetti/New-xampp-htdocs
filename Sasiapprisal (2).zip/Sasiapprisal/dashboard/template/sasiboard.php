<?php
session_start();
include '../../backend/dashcount.php';
include '../../backend/db.php';
$email = $_SESSION["email"];
@$sasiid = $_SESSION["sasiid"];
@$name = $_SESSION["name"];
$details_of_emp = "select *from details where Email='$email' and Sasiid='$sasiid'";
$execute_query = mysqli_query($connection, $details_of_emp);
$details_row = mysqli_fetch_array($execute_query);
@$emp_name = $details_row['Name'];
@$emp_Designation = $details_row['Des'];
@$emp_dep = $details_row['Dep'];
@$emp_dob = $details_row['DOB'];
@$emp_join = $details_row['DOJ'];
@$emp_aos = $details_row['AOS'];
@$emp_phone = $details_row['Phone'];
@$emp_email = $details_row['Email'];
@$emp_profile = $details_row['Image'];

/* Qualification fetch code*/
$quali_of_emp = "select *from qualifications where Sasiid='$sasiid'";
$execute_query1 = mysqli_query($connection, $quali_of_emp);
$coun = 0;
/* Training fetch code*/
$training_of_emp = "select *from training where Sasiid='$sasiid'";
$execute_query2 = mysqli_query($connection, $training_of_emp);
$coun1 = 0;
/* Teaching fetch code*/
$teaching_of_emp = "select *from teaching where Sasiid='$sasiid'";
$execute_query3 = mysqli_query($connection, $teaching_of_emp);
$coun2 = 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Majestic Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="../../middleware/updategen.js"></script>
  <script src="../../middleware/qualification.js"></script>
  <script src="../../middleware/updateall.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body onload="allhide()">
  <?php
  if ($email == "admin@gmail.com") {
  ?>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex justify-content-center">
          <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
            <a class="navbar-brand brand-logo" href="index.html"><img src="../../assets/sasi.jpeg" alt="logo" /></a>
            <a class="navbar-brand brand-logo-mini" href="index.html"><img src="../../assets/sasi.jpeg" alt="logo" /></a>
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="mdi mdi-sort-variant"></span>
            </button>
          </div>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                <img src="images/faces/face5.jpg" alt="profile" />
                <span class="nav-profile-name">Admin</span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="sasiboard">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="inviteemp">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Invite Employees</span>
              </a>
            </li>
            <!-- <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
              aria-controls="ui-basic">
              <i class="mdi mdi-view-headline menu-icon"></i>
              <span class="menu-title">Forms</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form A</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form B</a></li>
              </ul>
            </div>
          </li> -->


            <li class="nav-item">
              <a class="nav-link" href="emplist">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Employees List</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="appraisai">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">APPRAISAL</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="formb">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">Formb</span>
              </a>
            </li>

          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between flex-wrap">
                  <div class="d-flex align-items-end flex-wrap">
                    <div class="me-md-3 me-xl-5">
                      <h2>SITE APPRAISAL PORTAL</h2>
                      <p class="mb-md-0">Welcome Admin,</p>
                    </div>
                    <div class="d-flex">
                      <i class="mdi mdi-home text-muted hover-cursor"></i>
                      <p class="text-muted mb-0 hover-cursor">&nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;</p>
                      <p class="text-primary mb-0 hover-cursor">Analytics</p>
                    </div>
                  </div>
                  <div class="d-flex justify-content-between align-items-end flex-wrap">

                    <a href="#" style="color: white;" class="btn btn-primary mt-2 mt-xl-0">Invite Employee</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body dashboard-tabs p-0">
                    <ul class="nav nav-tabs px-4" role="tablist">
                      <li class="nav-item">
                        <a class="nav-link active" id="overview-tab" data-bs-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
                      </li>
                    </ul>
                    <div class="tab-content py-0 px-0">
                      <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                        <div class="d-flex flex-wrap justify-content-xl-between">
                          <div class="d-none d-xl-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-account-plus icon-lg me-3 text-primary"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Total Employee Invited</small>
                              <div class="dropdown">
                                <a class="btn btn-secondary p-0 bg-transparent border-0 text-dark shadow-none font-weight-medium" href="#" role="button">
                                  <h5 class="mb-0 d-inline-block" id="msg"></h5>
                                </a>

                              </div>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-account-arrow-right me-3 icon-lg text-success"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Employees Registered</small>
                              <h5 class="me-2 mb-0" id="msg1"></h5>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-contact-mail me-3 icon-lg text-success"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">Total Mails Sent</small>
                              <h5 class="me-2 mb-0" id="msg2"></h5>
                            </div>
                          </div>
                          <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                            <i class="mdi mdi-download me-3 icon-lg text-warning"></i>
                            <div class="d-flex flex-column justify-content-around">
                              <small class="mb-1 text-muted">APPRAISAL</small>
                              <h5 class="me-2 mb-0">0</h5>
                            </div>
                          </div>

                        </div>
                      </div>


                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">SASI APPRAISAL</a>2022</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  <?php
  } else {
  ?>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="navbar-brand-wrapper d-flex justify-content-center">
          <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
            <a class="navbar-brand brand-logo" href="index.html"><img src="../../assets/sasi.jpeg" alt="logo" /></a>
            <a class="navbar-brand brand-logo-mini" href="index.html"><img src="../../assets/sasi.jpeg" alt="logo" /></a>
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
              <span class="mdi mdi-sort-variant"></span>
            </button>
          </div>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                <img src="../../assets/<?php echo $emp_profile; ?>" alt="profile" />
                <span class="nav-profile-name"><?php echo $email; ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item">
                  <i class="mdi mdi-logout text-primary"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item">
              <a class="nav-link" href="sasiboard">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Profile</span>
              </a>
            </li>
            <!-- <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
              aria-controls="ui-basic">
              <i class="mdi mdi-view-headline menu-icon"></i>
              <span class="menu-title">Forms</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form A</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form B</a></li>
              </ul>
            </div>
          </li> -->


            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-grid-large menu-icon"></i>
                <span class="menu-title">Forms</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">APPRAISAL</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="image">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">Image Upload</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="formb">
                <i class="mdi mdi-account menu-icon"></i>
                <span class="menu-title">Formb</span>
              </a>
            </li>

          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between flex-wrap">
                  <div class="d-flex align-items-end flex-wrap">
                    <div class="me-md-3 me-xl-5">
                      <h2>SITE APPRAISAL PORTAL</h2>
                      <p class="mb-md-0">Welcome <?php echo $name; ?>,</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Your General Information</h4>
                    <div class="text-end">
                      <svg id="update" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 172 172" style=" fill:#000000;">
                        <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal">
                          <path d="M0,172v-172h172v172z" fill="none"></path>
                          <path d="M0,172v-172h172v172z" fill="#cccccc"></path>
                          <g fill="#000000">
                            <path d="M123.4907,27.9502c-1.46701,0 -2.93563,0.55882 -4.05363,1.67968l-9.78694,9.78694l22.93325,22.93325l9.78694,-9.78694c2.24173,-2.24173 2.24173,-5.87127 0,-8.10726l-14.82598,-14.82599c-1.12086,-1.12086 -2.58662,-1.67968 -4.05364,-1.67968zM101.05016,48.01679l-65.93309,65.93309v22.93325h22.93325l65.93309,-65.93309z"></path>
                          </g>
                        </g>
                      </svg>
                    </div>
                    <p class="card-description">
                      Personal info
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" value="<?php echo $emp_name; ?>" id="upname" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Designation</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" value="<?php echo $emp_Designation; ?>" id="updes" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Department</label>
                          <div class="col-sm-9">
                            <select class="form-control form-control-sm" id="updep">
                              <?php
                              $dep = ["CSE", "ECE", "IT"];
                              ?>
                              <option selected hidden value="">Select Your Department</option>
                              <?php
                              foreach ($dep as $d) {
                                if ($emp_dep == $d) {
                              ?>
                                  <option value="<?php echo $emp_dep; ?>" selected><?php echo $emp_dep; ?></option>
                                <?php
                                } else {
                                ?>
                                  <option value="<?php echo $d; ?>"><?php echo $d; ?></option>
                              <?php
                                }
                              }
                              ?>
                              <option value="ECE" $select_value>ECE</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Date of Birth</label>
                          <div class="col-sm-9">
                            <input class="form-control" placeholder="dd/mm/yyyy" type="date" value="<?php echo $emp_dob; ?>" id="updob" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label">Date of Joining in
                            SITE</label>
                          <div class="col-sm-7">
                            <input type="date" class="form-control" placeholder="dd/mm/yyyy" value="<?php echo $emp_join; ?>" id="updoj" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-5 col-form-label">Area of
                            Specialization</label>
                          <div class="col-sm-7">
                            <select class="form-control form-control-sm" id="upaos">
                              <?php
                              $deps = ["CSE", "ECE", "IT"];
                              ?>
                              <option selected hidden value="">Select Your Specialization</option>
                              <?php
                              foreach ($deps as $d) {
                                if ($emp_aos == $d) {
                              ?>
                                  <option value="<?php echo $emp_aos; ?>" selected><?php echo $emp_aos; ?></option>
                                <?php
                                } else {
                                ?>
                                  <option value="<?php echo $d; ?>"><?php echo $d; ?></option>
                              <?php
                                }
                              }
                              ?>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Phone Number</label>
                            <div class="col-sm-9">
                              <input type="text" class="form-control" value="<?php echo $emp_phone; ?>" id="upphone" />
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Email ID</label>
                            <div class="col-sm-9">
                              <input type="email" class="form-control" value="<?php echo $emp_email; ?>" id="upemail" />
                            </div>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <div class="form-group row">
                            <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid">
                            <button style="color: white;" class="btn btn-primary" onclick="genupdate()" id="hide">Update</button>
                          </div>
                        </div>

                      </div>
                      <hr>
                      <p class="card-description">
                        Qualification
                      <p style="Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="qshow">Add</a>
                      </p>
                      </p>
                      <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
                              <th scope="col">Sno</th>
                              <th scope="col">Degree</th>
                              <th scope="col">University</th>
                              <th scope="col">College</th>
                              <th scope="col">State</th>
                              <th scope="col">Class</th>
                              <th scope="col">Year Of Passing</th>
                              <th scope="col">Edit</th>
                              <th scope="col">Delete</th>
                            </tr>
                          </thead>
                          <?php
                          while ($quali_row = mysqli_fetch_array($execute_query1)) {
                            @$quali_deg = $quali_row['Deg'];
                            @$quali_uni = $quali_row['University'];
                            @$quali_coll = $quali_row['College'];
                            @$quali_stat = $quali_row['State'];
                            @$quali_class = $quali_row['Clas'];
                            @$quali_yop = $quali_row['Yop'];
                            @$quan_param = $quali_row['Param'];
                            $coun = $coun + 1;
                          ?>
                            <tr>
                              <td><?php echo $coun; ?></td>
                              <td><?php echo $quali_deg; ?></td>
                              <td><?php echo $quali_uni; ?></td>
                              <td><?php echo $quali_coll; ?></td>
                              <td><?php echo $quali_stat; ?></td>
                              <td><?php echo $quali_class; ?></td>
                              <td><?php echo $quali_yop; ?></td>
                              <td><a class="btn btn-warning" href="updatetemp?paramterconfigauth=<?php echo $quan_param; ?>">Edit</a></td>
                              <td><a class="btn btn-danger" onclick="del('<?php echo $quan_param; ?>')">Delete</a></td>
                            </tr>
                          <?php
                          }
                          ?>
                          <tbody>
                            <?php
                            if ($coun == 0) {
                            ?>
                              <tr>
                                <td colspan="7">
                                  <center><b>No Data Found</b></center>
                                  <hr>
                                </td>
                              </tr>
                            <?php
                            }
                            ?>
                            <tr>
                            </tr>

                          </tbody>
                        </table>
                      </div>
                      <br>
                      <div id="qdiv">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Degree</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="deg">
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">University</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="uni">
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">College</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="coll">
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">State</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="state">
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Class</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="clas">
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-2 col-form-label">Year of Pass</label>
                              <div class="col-sm-10">
                                <input type="date" class="form-control" id="yop">
                              </div>
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="form-group row">
                              <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid1">
                              <button style="color: white;" class="btn btn-primary" onclick="qualifications()" id="hide">Insert</button>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr>
                      <p class="card-description">
                        Rank/Prizes/Medals won at College / University during education/in
                        service
                      <p style="Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="rshow">Add</a></p>
                      </p>
                      <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Diploma/Degree</th>
                            <th scope="col">University</th>
                            <th scope="col">College</th>
                            <th scope="col">State</th>
                            <th scope="col">Class</th>
                            <th scope="col">Year Of Passing</th>


                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td colspan="7">
                              <center><b>No Data Found</b></center>
                              <hr>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <div id="rdiv">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">From</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">State</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Address 2</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Postcode</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">City</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Country</label>
                              <div class="col-sm-9">
                                <select class="form-control form-control-lg">
                                  <option>America</option>
                                  <option>Italy</option>
                                  <option>Russia</option>
                                  <option>Britain</option>
                                </select>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr>
                      <p class="card-description">Additional Training
                      <p style="Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="ashow">Add</a></p>
                      </p>
                      <table class="table">

                        <tr>
                          <th scope="col" rowspan="2">Sno</th>
                          <th scope="col" colspan="2">
                            <center>Period</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Total Period of Training in Weeks</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Nature of Program</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Institution</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Remarks</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Edit</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Delete</center>
                          </th>
                        </tr>
                        <tr>
                          <td>From</td>
                          <td>To</td>
                        </tr>
                        <?php
                        while ($train_det = mysqli_fetch_array($execute_query2)) {
                          $coun1 = $coun1 + 1;
                        ?>
                          <tr>
                            <td><?php echo $coun1; ?></td>
                            <td><?php echo  $train_det['Pfrom']; ?></td>
                            <td><?php echo  $train_det['Pto']; ?></td>
                            <td><?php echo  $train_det['Tper']; ?></td>
                            <td><?php echo  $train_det['Nop']; ?></td>
                            <td><?php echo  $train_det['Institution']; ?></td>
                            <td><?php echo  $train_det['Remarks']; ?></td>
                            <td><a class="btn btn-warning" href="trainingupdate?paramterconfigauth=<?php echo $train_det['Param']; ?>">Edit</a></td>
                            <td><a class="btn btn-danger" onclick="del1('<?php echo $train_det['Param']; ?>')">Delete</a></td>
                          </tr>
                        <?php
                        }
                        ?>
                        <?php
                        if ($coun1 == 0) {
                        ?>
                          <tr>
                            <td colspan="7">
                              <center><b>No Data Found</b></center>
                              <hr>
                            </td>
                          </tr>
                        <?php
                        }
                        ?>

                      </table>
                      <div id="adiv">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Period From</label>
                              <div class="col-sm-9">
                                <input type="date" class="form-control" id="pf" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Period To</label>
                              <div class="col-sm-9">
                                <input type="date" class="form-control" id="pt" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-5 col-form-label">Total Period of Training</label>
                              <div class="col-sm-7">
                                <input type="text" class="form-control" id="tpot" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Nature of Program</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="nop" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Institution</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="ini" />
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group row">
                              <label class="col-sm-3 col-form-label">Remarks</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="Remarks" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid2">
                            <button style="color: white;" class="btn btn-primary" onclick="training()" id="hide">Insert</button>
                          </div>
                        </div>
                      </div>
                      <hr>
                      <p class="card-description">Total Experience
                      <p style="Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="tshow">Add</a></p>
                      </p>

                      <table class="table">

                        <tr>
                          <th scope="col" rowspan="2">Sno</th>
                          <th scope="col" rowspan="2">
                            <center>Position Held</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Status</center>
                          </th>
                          <th scope="col" colspan="2">
                            <center>Duration</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>No of Year(Fraction Allowed)</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Name of Organization</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Edit</center>
                          </th>
                          <th scope="col" rowspan="2">
                            <center>Delete</center>
                          </th>
                        </tr>
                        <tr>
                          <td>From</td>
                          <td>To</td>

                        </tr>
                        <?php
                        while ($teach_det = mysqli_fetch_array($execute_query3)) {
                          $coun2 = $coun2 + 1;
                        ?>
                        <tr>
                          <td><?php echo $coun2; ?></td>
                          <td><?php echo  $teach_det['Pheld']; ?></td>
                          <td><?php echo  $teach_det['Status']; ?></td>
                          <td><?php echo  $teach_det['Df']; ?></td>
                          <td><?php echo  $teach_det['Dt']; ?></td>
                          <td><?php echo  $teach_det['Fraction']; ?></td>
                          <td><?php echo  $teach_det['Insti']; ?></td>
                          <td><a class="btn btn-warning" href="teachingupdate?paramterconfigauth=<?php echo $teach_det['Param']; ?>">Edit</a></td>
                          <td><a class="btn btn-danger" onclick="del2('<?php echo $teach_det['Param']; ?>')">Delete</a></td>
                        </tr>
                        <?php
                        }
                        ?>
                        <?php
                        if($coun2 == 0)
                        {
                        ?>
                        <tr>
                          <td colspan="8">
                            <center><b>No Data Found</b></center>
                            <hr>
                          </td>
                        </tr>
                        <?php
                        }
                        ?>

                      </table>
                      <div id="tdiv">
                        <div id="adiv">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Position Held</label>
                                <div class="col-sm-9">
                                  <input type="text" class="form-control" id="ph"/>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                <select class="form-control form-control-sm" id="status">
                                    <option value="Temporary">Temporary</option>
                                    <option value="Permanent">Permanent</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Duration From</label>
                                <div class="col-sm-9">
                                  <input type="date" class="form-control" id="df"/>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Duration To</label>
                                <div class="col-sm-9">
                                  <input type="date" class="form-control" id="dt" />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">No. of years(Fraction allowed)</label>
                                <div class="col-sm-9">
                                  <input type="text" class="form-control" id="noy"/>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Name of the University /Institute/ Organization</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="nou"/>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                          <div class="form-group row">
                            <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid3">
                            <button style="color: white;" class="btn btn-primary" onclick="teaching()" id="hide">Insert</button>
                          </div>
                        </div>
                          </div>
                        </div>
                      </div>
                      <hr>
                      <p class="card-description">
                        Instructions
                      <p style="Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="ishow">Show</a></p>
                      </p>
                      <div id="idiv">
                        <label>The appraisal form consists of the following Components, Maximum
                          macros for each of the
                          components and the scaling carried</label>
                        <table class="table">

                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">
                              <center>Category</center>
                            </th>
                            <th scope="col">
                              <center>Maximum Marks</center>
                            </th>

                          </tr>
                          <tr>
                            <td>1</td>
                            <td style="text-align:center">Teaching-Learning And Evaluation
                            </td>
                            <td>300</td>
                          </tr>
                          <tr>
                            <td>2</td>
                            <td style="text-align:center">Research and Allied Contributions
                            </td>
                            <td>150</td>
                          </tr>
                          <tr>
                            <td>3</td>
                            <td style="text-align:center">Administration</td>
                            <td>150</td>
                          </tr>
                          <tr>
                            <td>4</td>
                            <td style="text-align:center">Extension Activities</td>
                            <td>150</td>
                          </tr>
                          <tr>
                            <td style="text-align: right;" align="right" colspan="2">Total
                            </td>
                            <td>750</td>
                          </tr>
                          <tr>
                            <td style="text-align: right; font-weight: bold;" align="right" colspan="2">Additional Points as
                              per Choice</td>
                            <td>250</td>
                          </tr>
                          <tr>
                            <td style="text-align: right;" align="right" colspan="2">Grand
                              Total Points</td>
                            <td>1000</td>
                          </tr>
                        </table>
                        <div style="text-align: left;">
                          <ol>
                            <li>The total score considering items number 1 to 4 is for 750
                              marks, as shown in the above table. Additionally, a faculty
                              can gain additional 250 marks for any one category between
                              S.No 2 to 4 in the above table as per their area of Interest
                              and Expertise.<br><br></li>
                            <li>In Category-I (300 Marks), The maximum score from S.No-1 to
                              S.No-13 is 270 Marks and S.No-14 HOD Assessment is Mandatory
                              for 30Marks.<br><br></li>
                            <li>Suppose a faculty wants 250 additional marks added to the
                              RESEARCH AND ALLIED CONTRIBUTIONS Category (i.e. S.No 2),
                              then the scoring composition would be (300 + 400 + 150 +
                              150= 1000) or if any faculty wants 250 additional marks
                              added to the EXTENSION ACTIVITIES Category (i.e. S.No 4),
                              then the scoring composition would be (300 + 150 + 150 + 400
                              = 1000)<br><br> </li>
                            <li>The period considered for Category 1 (S.No.1) - 1st July
                              2020 to 30th June 2021<br><br></li>
                            <li>The period considered for Category 2 (S.No.2) - 1st Jan 2020
                              to 31st Dec 2020<br><br></li>
                            <li>The period considered for Category 3 (S.No.3) - 1st July
                              2020 to 30th June 2021<br><br></li>
                            <li>The period considered for Category 4 (S.No.4) - 1st July
                              2020 to 30th June 2021<br><br></li>
                            <li>Faculty has to submit all the proofs for all the points
                              claimed duly approved by the HOD concerned.</li>
                          </ol>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--<div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body dashboard-tabs p-0">
                  <ul class="nav nav-tabs px-4" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active" id="overview-tab" data-bs-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
                    </li>
                  </ul>
                  <div class="tab-content py-0 px-0">
                    <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                      <div class="d-flex flex-wrap justify-content-xl-between">
                        <div class="d-none d-xl-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                          <i class="mdi mdi-account-plus icon-lg me-3 text-primary"></i>
                          <div class="d-flex flex-column justify-content-around">
                            <small class="mb-1 text-muted">Total Employee Invited</small>
                            <div class="dropdown">
                              <a class="btn btn-secondary p-0 bg-transparent border-0 text-dark shadow-none font-weight-medium" href="#" role="button">
                                <h5 class="mb-0 d-inline-block" id="msg"></h5>
                              </a>

                            </div>
                          </div>
                        </div>
                        <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                          <i class="mdi mdi-account-arrow-right me-3 icon-lg text-success"></i>
                          <div class="d-flex flex-column justify-content-around">
                            <small class="mb-1 text-muted">Employees Registered</small>
                            <h5 class="me-2 mb-0" id="msg1"></h5>
                          </div>
                        </div>
                        <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                          <i class="mdi mdi-contact-mail me-3 icon-lg text-success"></i>
                          <div class="d-flex flex-column justify-content-around">
                            <small class="mb-1 text-muted">Total Mails Sent</small>
                            <h5 class="me-2 mb-0" id="msg2"></h5>
                          </div>
                        </div>
                        <div class="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                          <i class="mdi mdi-download me-3 icon-lg text-warning"></i>
                          <div class="d-flex flex-column justify-content-around">
                            <small class="mb-1 text-muted">APPRAISAL</small>
                            <h5 class="me-2 mb-0">0</h5>
                          </div>
                        </div>

                      </div>
                    </div>


                  </div>
                </div>
              </div>
            </div>-->
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">SASI APPRAISAL</a>2022</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  <?php
  }
  ?>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <script src="vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/data-table.js"></script>
  <script src="js/jquery.dataTables.js"></script>
  <script src="js/dataTables.bootstrap4.js"></script>
  <!-- End custom js for this page-->

  <script src="js/jquery.cookie.js" type="text/javascript"></script>
  <script src="../../middleware/dashcount.js"></script>
  <script>
    $(document).ready(function() {

      $("#qshow").click(function() {
        $("#qdiv").toggle();
      });
      $("#rshow").click(function() {
        $("#rdiv").toggle();
      });
      $("#ashow").click(function() {
        $("#adiv").toggle();
      });
      $("#tshow").click(function() {
        $("#tdiv").toggle();
      });
      $("#ishow").click(function() {
        $("#idiv").toggle();
      });
    });
  </script>
  <script>
    function allhide() {


      document.getElementById('qdiv').style.display = "none";
      document.getElementById('rdiv').style.display = "none";
      document.getElementById('adiv').style.display = "none";
      document.getElementById('tdiv').style.display = "none";
      document.getElementById('idiv').style.display = "none";
    }
  </script>
  <script>
    $("#hide").hide();
    $('#upname,#updes,#updob,#updoj,#upphone,#upemail').attr('readonly', true);
    $('#updeg,#upuni,#upcoll,#upstat,#upclass,#upyop').attr('readonly', true);
    $('#updep,#upaos').attr('disabled', true);
    $(document).ready(function() {
      $("#update").click(function() {
        $("#hide").show();
        $('#upname,#updes,#updob,#updoj,#upphone,#upemail').attr('readonly', false);
        $('#updep,#upaos').attr('disabled', false);
      });
      $("#update1").click(function() {
        $('#updeg,#upuni,#upcoll,#upstat,#upclass,#upyop').attr('readonly', false);
      });
    });
  </script>
</body>

</html>