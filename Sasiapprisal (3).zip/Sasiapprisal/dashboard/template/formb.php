<?php
session_start();
include '../../backend/dashcount.php';
include '../../backend/db.php';
$email = $_SESSION["email"];
@$sasiid = $_SESSION["sasiid"];
@$name = $_SESSION["name"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
            shrink-to-fit=no">
    <title>Majestic Admin</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="images/favicon.png" />
    <script src="../../middleware/formb.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body onload="allhide()">
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                        <span class="mdi mdi-sort-variant"></span>
                    </button>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav mr-lg-4 w-100">
                    <li class="nav-item nav-search d-none d-lg-block w-100">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="search">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search">
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown me-1">
                        <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-message-text mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">David Grey
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        The meeting is cancelled
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">Tim Cook
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        New product launch
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal"> Johnson
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        Upcoming board meeting
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown me-4">
                        <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-success">
                                        <i class="mdi mdi-information mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Application Error</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Just now
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-warning">
                                        <i class="mdi mdi-settings mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Settings</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Private message
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-info">
                                        <i class="mdi mdi-account-box mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">New user registration</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        2 days ago
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="images/faces/face5.jpg" alt="profile" />
                            <span class="nav-profile-name">Louis Barnett</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">
                            <i class="mdi mdi-home menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inviteemp.html">
                            <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                            <span class="menu-title">Invite Employees</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
                            aria-controls="ui-basic">
                            <i class="mdi mdi-view-headline menu-icon"></i>
                            <span class="menu-title">Forms</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="ui-basic">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form
                                        A</a></li>
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form
                                        B</a></li>
                            </ul>
                        </div>
                    </li> -->


                    <li class="nav-item">
                        <a class="nav-link" href="emplist.html">
                            <i class="mdi mdi-grid-large menu-icon"></i>
                            <span class="menu-title">Employees List</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
                            <i class="mdi mdi-account menu-icon"></i>
                            <span class="menu-title">APPRAISAL</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="auth">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="appraisai.html"> Form A </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formb.html"> Form B </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formc.html"> Form C </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formd.html"> Form D</a></li>
                                <li class="nav-item"> <a class="nav-link" href="forme.html"> Form E </a></li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </nav>

            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-12 grid-margin">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Teaching-Learning and Evaluation</h4>

                                    <p class="card-description">
                                        (Details to be filled from 1-Jul-19 to 30-Jun-20)
                                    </p>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">S. No</th>
                                                <th scope="col">
                                                    <center>Nature of Activity</center>
                                                </th>
                                                <th scope="col" class="verticalTableHeader">Self-Appraisal Score
                                                </th>
                                                <th scope="col" class="verticalTableHeader">Score after Verification
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th></th>
                                                <th>
                                                    <small style="font-size: 10px;">Sessions delivered against the
                                                        sessions planned(in %)
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Seshow">Add</a>
                                                        </p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th class="verticalTableHeader">S.No </th>
                                                            <th class="verticalTableHeader">Course Code</th>
                                                            <th class="verticalTableHeader">Course Name</th>
                                                            <th class="verticalTableHeader">Branch</th>
                                                            <th class="verticalTableHeader">Year<br>I/II/III/IV/V
                                                            </th>
                                                            <th class="verticalTableHeader">Semester</th>
                                                            <th class="verticalTableHeader">Section</th>
                                                            <th class="verticalTableHeader">No of sessions Planned
                                                            </th>
                                                            <th class="verticalTableHeader">No of sessions Delivered
                                                            </th>
                                                            <th class="verticalTableHeader">%</th>
                                                            <th class="verticalTableHeader">Marks Scored</th>

                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td colspan="10" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br>
                                                    <div id="Sediv">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Code</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cc">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Name</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cn">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Branch</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="bra">
                                                                            <option selected hidden value="">Select Your Branch</option>
                                                                            <option value="CSE">CSE</option>
                                                                            <option value="ECE">ECE</option>
                                                                            <option value="ECE">IT</option>
                                                                            <option value="ECE">MECH</option>
                                                                            <option value="ECE">ECE</option>
                                                                            <option value="ECE">CIVIL</option>
                                                                    
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Year</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="year">
                                                                            <option selected hidden value="">Select Your year</option>
                                                                            <option value="I">I</option>
                                                                            <option value="II">II</option>
                                                                            <option value="III">III</option>
                                                                            <option value="IV">IV</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Semister</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sem">
                                                                            <option selected hidden value="">Select Your Semister</option>
                                                                            <option value="I-I">I-I</option>
                                                                            <option value="I-II">I-II</option>
                                                                            <option value="II-I">II-I</option>
                                                                            <option value="II-II">II-II</option>
                                                                            <option value="III-I">III-I</option>
                                                                            <option value="III-II">III-II</option>
                                                                            <option value="IV-I">IV-I</option>
                                                                            <option value="IV-II">IV-II</option>


                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Section</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sec">
                                                                            <option selected hidden value="">Select Your sSection</option>
                                                                            <option value="A">A</option>
                                                                            <option value="B">B</option>
                                                                            <option value="C">C</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">No of Sessions Planned</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="nosp">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">No of Sessions Delivered</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="nosd">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">%</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="per">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Scored</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="ms">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid4">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(91% to 100% = 10 Marks, 81% to
                                                        90%=8 Marks, 71% to 80%=5 Marks, 70% and less = 0 Marks
                                                        )
                                                    </small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>2</th>
                                                <th>
                                                    <small style="font-size: 10px;">Other Academics
                                                        Activities
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Otshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th class="verticalTableHeader">S.No </th>
                                                            <th class="verticalTableHeader">Course Code</th>
                                                            <th class="verticalTableHeader">Course Name</th>
                                                            <th class="verticalTableHeader">Branch</th>
                                                            <th class="verticalTableHeader">Year<br>I/II/III/IV/V
                                                            </th>
                                                            <th class="verticalTableHeader">Semester</th>
                                                            <th class="verticalTableHeader">Section</th>
                                                            <th class="verticalTableHeader">No of sessions Planned
                                                            </th>
                                                            <th class="verticalTableHeader">No of sessions Delivered
                                                            </th>
                                                            <th class="verticalTableHeader">%</th>
                                                            <th class="verticalTableHeader">Marks Scored</th>

                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td colspan="10" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br>

                                                    <div id="Otdiv">
                                                        
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(For each activity; 91% to 100%
                                                        = 6 Marks,81% to 90%=4 Marks,71% to 80%=2 Marks, 70% and
                                                        less = 0 Marks )</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>3</th>
                                                <th>
                                                    <small style="font-size: 10px;">Attainment of Course outcomes (
                                                        to be filled in consultation with course co-ordinator &
                                                        Professor Incharge-Academics)
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Atshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <tr>
                                                                <th>Course Code</th>
                                                                <th>Course Name</th>
                                                                <th>No. of expected course outcomes</th>
                                                                <th>No. of outcomesattained</th>
                                                                <th>% <br> Achieved</th>
                                                                <th>Marks Obtained</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td colspan="5" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Atdiv">
                                                    <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Code</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="ccc">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Name</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cnn">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">No. of expected course outcomes</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="nco">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">No. of outcomesattained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="noc">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">% Acheived</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="pera">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="moo">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid5">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb3()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(100% = 10 points in each course
                                                        or section and in proportion)
                                                    </small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>4</th>
                                                <th>
                                                    <small style="font-size: 10px;">Assessment and Evaluation
                                                        related
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Asshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Course Code</th>
                                                            <th>Marks Obtained</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Setting Sem End Question Paper</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Setting Sem in Tests related question Paper</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Setting Assignments related question paper</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Developing Solutions to the question papers</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Submission of marks in Time</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Course Handout preparation & circulation</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Asdiv">
                                                         <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="sseq">Setting Sem End Question Paper</option>
                                                                            <option value="ssit">Setting Sem in Tests related question Paper</option>
                                                                            <option value="sarq">Setting Assignments related question paper</option>
                                                                            <option value="dstt">Developing Solutions to the question papers</option>
                                                                            <option value="somi">Submission of marks in Time</option>
                                                                            <option value="chp">Course Handout preparation & circulation</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Code</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cc2">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo2">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid6">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb4()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(Each Activity=5Marks per
                                                        Course)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>5</th>
                                                <th>
                                                    <small style="font-size: 10px;">Examination work such as
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Exshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Marks Obtained</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Invigilation</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Evaluation</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Scrutiny</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Flying Squad Duties</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="1" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Exdiv">
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya1">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="inv">Invigilation</option>
                                                                            <option value="eva">Evaluation</option>
                                                                            <option value="scr">Scrutiny</option>
                                                                            <option value="fsd">Flying Squad Duties</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo3">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid7">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb5()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                        </div>
                            
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(Each Activity=5Marks per
                                                        Course)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>6</th>
                                                <th>
                                                    <small style="font-size: 10px;">Use of Innovative Teaching -
                                                        Learning Methodologies; use of ICT;
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Usshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Marks Obtained</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>ICT Based Teaching material posting on
                                                                    e-learning site</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>E-Content and Developing Video Lectures</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Innovating teaching methodologies
                                                                    (Lectures/Practicals/Skilling)</td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="1" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Usdiv">
                                                         <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya2">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="ict">ICT Based Teaching material posting on e-learning site</option>
                                                                            <option value="ecd">E-Content and Developing Video Lectures</option>
                                                                            <option value="itm">Innovating teaching methodologies (Lectures/Practicals/Skilling)</option>
                                                                            
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo4">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid8">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb6()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                        </div>  
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(Each Activity=10Marks
                                                        Max)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>7</th>
                                                <th>
                                                    <small style="font-size: 10px;">Additional Contribution
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Adshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>No. of Hours Taken</th>
                                                            <th>Marks Obtained</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Remedial classes taken for slow learners</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Bridge Course hrs taken</td>
                                                                <td></td>
                                                                <td></td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Addiv">
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya3">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="rct">Remedial classes taken for slow learners</option>
                                                                            <option value="bch">Bridge Course hrs taken</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">No. of Hours Taken</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="noht">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo5">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid9">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb7()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(Each activity: 20 points for 10
                                                        hours and in proportion)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>8</th>
                                                <th>
                                                    <small style="font-size: 10px;">Student Performance
                                                        Monitoring
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Stshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Maximum Marks</th>
                                                            <th>Marks Obtained</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Intimation of Student Progress to parents &
                                                                    Concerned Authorities (Counselling Activity)
                                                                </td>
                                                                <td>20</td>
                                                                <td></td>
                                                            </tr>

                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Stdiv">
                                                       <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya4">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="iosp">Intimation of Student Progress to parents & Concerned Authorities (Counselling Activity)</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">maximum Marks</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="mm1">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="mm1">20</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo6">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid10">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb8()" id="hide">Insert</button>
                                                                </div>
                                                            </div> 
                                                        
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(Minimum Three Interactions with
                                                        the Parents is required to qualify)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>9</th>
                                                <th>
                                                    <small style="font-size: 10px;">Student Feedback
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Feshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Course Code</th>
                                                            <th>Semister</th>
                                                            <th>% of feedback Achieved</th>
                                                        </thead>
                                                        <tbody>


                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Average %age Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Fediv">
                                                    <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Code</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cc3">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Semister</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="semis">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">% of feedback Achieved</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="pofa">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid11">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb9()" id="hide">Insert</button>
                                                                </div>
                                                            </div> 
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">100% Average feedback = 50 Marks
                                                        and in proportion (All courses including Theory, Practicals,
                                                        Tutorials, Skilling as Mentioned in S No 1 and S No
                                                        2</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>10</th>
                                                <th>
                                                    <small style="font-size: 10px;">Student Pass %
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Pashow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Course Code</th>
                                                            <th>Semister</th>
                                                            <th> Pass % </th>
                                                        </thead>
                                                        <tbody>


                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Average % Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Padiv">
                                                    <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Course Code</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="cc4">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Semister</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="semis1">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Pass %</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="pasp">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid12">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb10()" id="hide">Insert</button>
                                                                </div>
                                                            </div> 
                                                        
                                                        
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(91% to 100% = 50 Marks,81% to
                                                        90%=45 Marks,71% to 80%=40 Marks, 70% and less = Proportion
                                                        Marks on Average % Obtained)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>11</th>
                                                <th>
                                                    <small style="font-size: 10px;">Contribution Through
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Coshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Maximum Marks</th>
                                                            <th> Marks Obtained </th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Guest Lecture(s) delivered</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Faculty orientation Lecture(s) delivered</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Subject Related Event(s) like Expos, Exhibitions
                                                                    etc</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Articles in college / department magazine and
                                                                    university volume(s)</td>
                                                                <td>10</td>
                                                            </tr>

                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Codiv">
                                                    <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya5">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="gld">Guest Lecture(s) delivered</option>
                                                                            <option value="fol">Faculty orientation Lecture(s) delivered</option>
                                                                            <option value="srel">Subject Related Event(s) like Expos, Exhibitions etc</option>
                                                                            <option value="aic">Articles in college / department magazine and university volume(s)</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya6">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="ten">10</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo7">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid13">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb11()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <hr>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>12</th>
                                                <th>
                                                    <small style="font-size: 10px;">Institutional Co-curricular
                                                        activities for students such as
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Inshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th>Maximum Marks</th>
                                                            <th> Marks Obtained </th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Field studies/educational tours</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>IRP training</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Placement activity/ Practice school</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Continous upgradation of knowledge in relevent
                                                                    field with value added sessions like Coursera,
                                                                    NPTL,MOOCS etc</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Contribution to bridge gap between industry
                                                                    expectations and academics</td>
                                                                <td>5</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Industry connect (related to course)</td>
                                                                <td>5</td>
                                                            </tr>

                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <div id="Indiv">
                                                        <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya7">
                                                                            <option selected hidden value="">select your activity</option>
                                                                            <option value="fse">Field studies/educational tours</option>
                                                                            <option value="irp">IRP training</option>
                                                                            <option value="pap">Placement activity/ Practice school</option>
                                                                            <option value="cuo">Continous upgradation of knowledge in relevent field with value added sessions like Coursera, NPTL,MOOCS etc</option>
                                                                            <option value="ctb">Contribution to bridge gap between industry expectations and academics</option>
                                                                            <option value="icr">Industry connect (related to course)</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Maximum Marks</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya8">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="te">10</option>
                                                                            <option value="fiv">5</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo8">
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid14">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb12()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                    </div>
                                                    <hr>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>13</th>
                                                <th>
                                                    <small style="font-size: 10px;">Participation in
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Ipshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th> Marks/ Activity</th>
                                                            <th> Marks Obtained </th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Short term training Programmes/ FDPs in
                                                                    educational technology organised by premier
                                                                    institutes/ corporates</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>New course design &Curriculum development</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Coding competitions (general/academic)</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Any other relevant activity: Specify with proof
                                                                </td>
                                                                <td>10</td>
                                                            </tr>


                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <div id="Ipdiv">
                                                         <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya9">
                                                                            <option selected hidden value="">select your activity</option>
                                                                            <option value="strp">Short term training Programmes/ FDPs in educational technology organised by premier institutes/ corporates</option>
                                                                            <option value="ncd">New course design &Curriculum development</option>
                                                                            <option value="ccg">Coding competitions (general/academic)</option>
                                                                            <option value="aor">Any other relevant activity: Specify with proof</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks/ Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya10">
                                                                            <option selected hidden value="">select your activity</option>
                                                                            <option value="ten1">10</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo9">
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid15">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb13()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                                        
                                                    </div>
                                                    <hr>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <th>14</th>
                                                <th>
                                                    <small style="font-size: 10px;">Academic Assessment by the HOD
                                                        <p style=" Text-align:right; color: white; margin-top: -1cm;"><a class="btn btn-success" id="Acshow">Add</a></p>
                                                    </small>
                                                    <table>
                                                        <thead>
                                                            <th>Activity</th>
                                                            <th> Max Marks</th>
                                                            <th> Marks Obtained </th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Class room discipline</td>
                                                                <td>5</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Time Management & Class adjustment</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Syllabus completion in time</td>
                                                                <td>10</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Feedback by Peers/Principal/Dean/COE</td>
                                                                <td>5</td>
                                                            </tr>


                                                            <tr>
                                                                <td colspan="2" style="text-align: right;">
                                                                    <hr>Total Marks Obtained
                                                                </td>
                                                                <td></td>

                                                            </tr>

                                                        </tbody>

                                                    </table>
                                                    <div id="Acdiv">
                                                    <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Activity</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya11">
                                                                            <option selected hidden value="">select your activity</option>
                                                                            <option value="crd">Class room discipline</option>
                                                                            <option value="tmc">Time Management & Class adjustment</option>
                                                                            <option value="sci">Syllabus completion in time</option>
                                                                            <option value="fbp">Feedback by Peers/Principal/Dean/COE</option>
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Maximum Marks</label>
                                                                    <div class="col-sm-9">
                                                                        <select class="form-control form-control-sm" id="sya12">
                                                                            <option selected hidden value="">Select Your Activity</option>
                                                                            <option value="ten2">10</option>
                                                                            <option value="five1">5</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <label class="col-sm-3 col-form-label">Marks Obtained</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control" id="mo10">
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sasiid; ?>" id="sasiid16">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="formb14()" id="hide">Insert</button>
                                                                </div>
                                                            </div>  
                                                    </div>
                                                    <hr>
                                                    <small style="font-size: 10px;">(To be filled by respective HOD
                                                        by collecting the information from year/class coordinator,
                                                        Course Co-ordinator/ Concerned Incharges)</small>
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </tbody>



                                    </table>






                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="" target="_blank">Project Expo.com </a>2022</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <script>
        $(document).ready(function() {

            $("#Seshow").click(function() {
                $("#Sediv").toggle();
            });
            $("#Otshow").click(function() {
                $("#Otdiv").toggle();
            });
            $("#Atshow").click(function() {
                $("#Atdiv").toggle();
            });
            $("#Asshow").click(function() {
                $("#Asdiv").toggle();
            });
            $("#Exshow").click(function() {
                $("#Exdiv").toggle();
            });
            $("#Usshow").click(function() {
                $("#Usdiv").toggle();
            });
            $("#Adshow").click(function() {
                $("#Addiv").toggle();
            });
            $("#Stshow").click(function() {
                $("#Stdiv").toggle();
            });
            $("#Feshow").click(function() {
                $("#Fediv").toggle();
            });
            $("#Pashow").click(function() {
                $("#Padiv").toggle();
            });
            $("#Coshow").click(function() {
                $("#Codiv").toggle();
            });
            $("#Inshow").click(function() {
                $("#Indiv").toggle();
            });
            $("#Ipshow").click(function() {
                $("#Ipdiv").toggle();
            });
            $("#Acshow").click(function() {
                $("#Acdiv").toggle();
            });
        });
    </script>
    <script>
        function allhide() {


            document.getElementById('Sediv').style.display = "none";
            document.getElementById('Otdiv').style.display = "none";

            document.getElementById('Atdiv').style.display = "none";
            document.getElementById('Asdiv').style.display = "none";
            document.getElementById('Exdiv').style.display = "none";
            document.getElementById('Usdiv').style.display = "none";
            document.getElementById('Addiv').style.display = "none";
            document.getElementById('Stdiv').style.display = "none";
            document.getElementById('Fediv').style.display = "none";
            document.getElementById('Padiv').style.display = "none";
            document.getElementById('Codiv').style.display = "none";
            document.getElementById('Indiv').style.display = "none";
            document.getElementById('Ipdiv').style.display = "none";
            document.getElementById('Acdiv').style.display = "none";

        }
    </script>
    <!-- plugins:js -->
    <script src="vendors/base/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="vendors/chart.js/Chart.min.js"></script>
    <script src="vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/hoverable-collapse.js"></script>
    <script src="js/template.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="js/dashboard.js"></script>
    <script src="js/data-table.js"></script>
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap4.js"></script>
    <!-- End custom js for this page-->

    <script src="js/jquery.cookie.js" type="text/javascript"></script>
</body>

</html>