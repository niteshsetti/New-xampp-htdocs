<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1,
            shrink-to-fit=no">
    <title>Majestic Admin</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- plugins:css -->
    <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="vendors/base/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <link rel="stylesheet" href="vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="images/favicon.png" />
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="../../middleware/forme.js"></script>

</head>

<body onload="allhide()">
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex justify-content-center">
                <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
                    <a class="navbar-brand brand-logo" href="index.html"><img src="./images/logo.png" alt="logo" /></a>
                    <a class="navbar-brand brand-logo-mini" href="index.html"><img src="./images/logo.png"
                            alt="logo" /></a>
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button"
                        data-toggle="minimize">
                        <span class="mdi mdi-sort-variant"></span>
                    </button>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav mr-lg-4 w-100">
                    <li class="nav-item nav-search d-none d-lg-block w-100">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="search">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                            </div>
                            <input type="text" class="form-control" placeholder="Search now" aria-label="search"
                                aria-describedby="search">
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown me-1">
                        <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center"
                            id="messageDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-message-text mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="messageDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">David Grey
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        The meeting is cancelled
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal">Tim Cook
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        New product launch
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                                </div>
                                <div class="item-content flex-grow">
                                    <h6 class="ellipsis font-weight-normal"> Johnson
                                    </h6>
                                    <p class="font-weight-light small-text text-muted mb-0">
                                        Upcoming board meeting
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item dropdown me-4">
                        <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown"
                            id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                            <i class="mdi mdi-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-success">
                                        <i class="mdi mdi-information mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Application Error</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Just now
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-warning">
                                        <i class="mdi mdi-settings mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">Settings</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Private message
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item">
                                <div class="item-thumbnail">
                                    <div class="item-icon bg-info">
                                        <i class="mdi mdi-account-box mx-0"></i>
                                    </div>
                                </div>
                                <div class="item-content">
                                    <h6 class="font-weight-normal">New user registration</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        2 days ago
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                            <img src="images/faces/face5.jpg" alt="profile" />
                            <span class="nav-profile-name">Louis Barnett</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="mdi mdi-settings text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">
                                <i class="mdi mdi-logout text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">
                            <i class="mdi mdi-home menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="inviteemp.html">
                            <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                            <span class="menu-title">Invite Employees</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false"
                            aria-controls="ui-basic">
                            <i class="mdi mdi-view-headline menu-icon"></i>
                            <span class="menu-title">Forms</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="ui-basic">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/buttons.html">Form
                                        A</a></li>
                                <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">Form
                                        B</a></li>
                            </ul>
                        </div>
                    </li> -->


                    <li class="nav-item">
                        <a class="nav-link" href="emplist.html">
                            <i class="mdi mdi-grid-large menu-icon"></i>
                            <span class="menu-title">Employees List</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#auth" aria-expanded="false"
                            aria-controls="auth">
                            <i class="mdi mdi-account menu-icon"></i>
                            <span class="menu-title">APPRAISAL</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="auth">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item"> <a class="nav-link" href="appraisai.html"> Form A </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formb.html"> Form B </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formc.html"> Form C </a></li>
                                <li class="nav-item"> <a class="nav-link" href="formd.html"> Form D</a></li>
                                <li class="nav-item"> <a class="nav-link" href="forme.html"> Form E </a></li>
                            </ul>
                        </div>
                    </li>

                </ul>
            </nav>

            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">

                        <!--<div class="col-12 grid-margin stretch-card">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title">Basic form elements</h4>
                          <p class="card-description">
                            Basic form elements
                          </p>
                          <form class="forms-sample">
                            <div class="form-group">
                              <label for="exampleInputName1">Name</label>
                              <input type="text" class="form-control" id="exampleInputName1" placeholder="Name">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputEmail3">Email address</label>
                              <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Email">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputPassword4">Password</label>
                              <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                            </div>
                            <div class="form-group">
                              <label for="exampleSelectGender">Gender</label>
                              <select class="form-control" id="exampleSelectGender">
                                <option>Male</option>
                                <option>Female</option>
                              </select>
                            </div>
                            <div class="form-group">
                              <label>File upload</label>
                              <input type="file" name="img[]" class="file-upload-default">
                              <div class="input-group col-xs-12">
                                <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                                <span class="input-group-append">
                                  <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                </span>
                              </div>
                            </div>
                            <div class="form-group">
                              <label for="exampleInputCity1">City</label>
                              <input type="text" class="form-control" id="exampleInputCity1" placeholder="Location">
                            </div>
                            <div class="form-group">
                              <label for="exampleTextarea1">Textarea</label>
                              <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>
                          </form>
                        </div>
                      </div>
                    </div>-->
                        <div class="col-12 grid-margin">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">EXTENSION ACTIVITIES
                                    </h4>
                                        <p class="card-description">
                                            (Details to be filled from 1-Jul-19 to 30-Jun-20)<br>
                                            Part A - For Compulsory Max Marks :150
                                            <p style=" Text-align:right; color: white; margin-top: -1cm;"><a
                                                class="btn btn-success" id="Pashow">Add</a></p>
                                        </p>
                                        <table width="100%">
                                            <thead>
                                                <th>S.No</th>
                                                <th width="70%">Nature of Activity</th>
                                                <th>Max Score</th>
                                                <th>Self-Appraisal Score</th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>
                                                        <br>
                                                        <b>Involvement in Activties that link Institute with
                                                            Community</b>
                                                        <ul>
                                                            <li>Participation for 7 continuous working days in a
                                                                semester in Smart Village project</li>
                                                            <li>activities for overall 30 hours per semester in NSS/
                                                                NCC/ YRC/CEA activities</li>
                                                            <li>Identified and solved a problem of community through
                                                                Socially relavent/ technical project</li>
                                                            <li>Any other Social service/community activity - 2 per
                                                                semester</li>
                                                        </ul>
                                                        <br>
                                                        <b>Specify the Following:</b>
                                                        <br><hr>
                                                        <table width="100%">
                                                            <thead>
                                                                <th>Date & Time</th>
                                                                <th>Nature of Activity</th>
                                                                <th>Place of Activity</th>
                                                                <th>Hours Participated</th>
                                                            </thead>
                                                            <tbody>
                                                                <td></td>
                                                                <td>Tree Planetation</td>
                                                                <td>Nalluru</td>
                                                                <td>30</td>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                    <td>150  and proportional for lesser duration</td>
                                                    <td>150</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <div id="Padiv">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">S.No</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="snow1"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Nature of Activity</label>
                                                        <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="drop1">
                                                                            <option selected hidden value="">Involvement in Activties that link Institute with Community</option>
                                                                            <option value="capd">Participation for 7 continuous working days in a semester in Smart Village project</option>
                                                                            <option value="adac">activities for overall 30 hours per semester in NSS/ NCC/ YRC/CEA activities</option>
                                                                            <option value="hod2">Identified and solved a problem of community through Socially relavent/ technical project</option>
                                                                            <option value="ahdh">Any other Social service/community activity - 2 per semester</option>
                                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Max Score</label>
                                                        <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="drop2">
                                                                            <option selected hidden value="">Select max Score</option>
                                                                            <option value="capd">150 and proportional for lesser duration</option>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Self-Appraisal Score</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="seas"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Date & Time</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="dta"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Nature of Activity</label>
                                                        <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="noa8" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Place of Activity</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="poa"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">	Hours Participated</label>
                                                        <div class="col-sm-9">
                                                        <input type="text" class="form-control" id="hpd"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sassid1; ?>" id="sassid1">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="forme1()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <p class="card-description">
                                            Part B - For Optional Extra 250 Marks:( for activities beyond the mention in Category A)
                                            <p style=" Text-align:right; color: white; margin-top: -1cm;"><a
                                                class="btn btn-success" id="Opshow">Add</a></p>
                                        </p>
                                        <table width="100%">
                                            <thead>
                                              <th>S. No</th>
                                              <th width="60%">Nature of Activity</th>
                                              <th>No. of Events</th>
                                              <th>Max Score</th>
                                              <th>Self - Appraisal Score</th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>Contributions to Disaster Assistance(Providing support for victims of major calamities like cyclones, fire accidents, Earth Quakes & floods etc.)</td>
                                                    <td></td>
                                                    <td>50 per incident</td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td>Community Awareness Building & Sensitization Program (organising awareness programs to educate people on Water harvesting, Girl Child education, Women rights and Empowerment,  De-Alcohol, Saving Trees, Environment conservation, Reduction in use of Plastic, traffic rules etc.)</td>
                                                    <td></td>
                                                    <td>100 per program</td>
                                                </tr><tr>
                                                    <td>3</td>
                                                    <td>Community Awareness Building & Sensitization Program (working as resource person for awareness sessions and educating people about Water harvesting, Girl Child education, Women rights and Empowerment, De-Alcohol, Saving Trees, Environment conservation, Reduction in use of Plastic  etc.)</td>
                                                    <td></td>
                                                    <td>50 per program</td>
                                                </tr>
                                                <tr>
                                                    <td>4</td>
                                                    <td>SMART VILLAGE PROJECT 
                                                        Score of adopted village should be minimum 40 marks of IGBC ( Indian Green Building concept)
                                                        </td>
                                                    <td></td>
                                                    <td>250</td>
                                                </tr><tr>
                                                    <td>5</td>
                                                    <td>Implementing CSR projects by corporates - through MOUs with worth of minimum Rupees 2 crores</td>
                                                    <td></td>
                                                    <td>250 & Proportional for lesser</td>
                                                </tr><tr>
                                                    <td>6</td>
                                                    <td>Implementing Social project in colloboration with UNESCO, WHO, UNICEF, UNDP etc.,</td>
                                                    <td></td>
                                                    <td>250</td>
                                                </tr><tr>
                                                    <td>7</td>
                                                    <td>Organizing programs like health camps, mother child health camps, blood donation camps, organ donation camps etc</td>
                                                    <td></td>
                                                    <td>50 per program</td>
                                                </tr><tr>
                                                    <td>8</td>
                                                    <td>Counseling sessions on issues related to Social sensitivity</td>
                                                    <td></td>
                                                    <td>50 per program</td>
                                                </tr><tr>
                                                    <td>9</td>
                                                    <td>contributions to social programs like swatch bharat abhiyan</td>
                                                    <td></td>
                                                    <td>10 per program</td>
                                                </tr><tr>
                                                    <td>10</td>
                                                    <td>Mentoring Social Start Ups</td>
                                                    <td></td>
                                                    <td>100</td>
                                                </tr>
                                                <tr>
                                                    <td>11</td>
                                                    <td>Awards / recognitions – govt/ non-govt</td>
                                                    <td></td>
                                                    <td>50</td>
                                                </tr><tr>
                                                    <td>12</td>
                                                    <td>Students awards/ medals – sports, cultural (inter university, state, national, international level)</td>
                                                    <td></td>
                                                    <td>50</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" align="right">Total Marks Obtained</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <div id="Opdiv">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">S.No</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="snow2"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">	Nature of Activity</label>
                                                        <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dro1">
                                                                            <option selected hidden value="">Select an Activity</option> 
                                                                            <option value="ctda">Contributions to Disaster Assistance(Providing support for victims of major calamities like cyclones, fire accidents, Earth Quakes & floods etc.)</option>
                                                                            <option value="caba"> Community Awareness Building & Sensitization Program (organising awareness programs to educate people on Water harvesting, Girl Child education, Women rights and Empowerment, De-Alcohol, Saving Trees, Environment conservation, Reduction in use of Plastic, traffic rules etc.)</option>
                                                                            <option value="cabs">Community Awareness Building & Sensitization Program (working as resource person for awareness sessions and educating people about Water harvesting, Girl Child education, Women rights and Empowerment, De-Alcohol, Saving Trees, Environment conservation, Reduction in use of Plastic etc.)</option>
                                                                            <option value="svps">SMART VILLAGE PROJECT Score of adopted village should be minimum 40 marks of IGBC ( Indian Green Building concept)</option>
                                                                            <option value="icpb">Implementing CSR projects by corporates - through MOUs with worth of minimum Rupees 2 crores</option>
                                                                            <option value="ispi">Implementing Social project in colloboration with UNESCO, WHO, UNICEF, UNDP etc.,</option>
                                                                            <option value="oplh">Organizing programs like health camps, mother child health camps, blood donation camps, organ donation camps etc</option>
                                                                            <option value="csoi">Counseling sessions on issues related to Social sensitivity</option>
                                                                            <option value="ctsp">contributions to social programs like swatch bharat abhiyan</option>
                                                                            <option value="mssu">Mentoring Social Start Ups</option>
                                                                            <option value="argn">Awards / recognitions - govt/ non-govt</option>
                                                                            <option value="sams">Students awards/ medals - sports, cultural (inter university, state, national, international level)</option>
                                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">No. of Events</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="noeven" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Max Score</label>
                                                        <div class="col-sm-9">
                                                        <select class="form-control form-control-sm" id="dro2">
                                                                            <option selected hidden value="">Select Max Score</option>
                                                                            <option value="fipi">50 per incident</option>
                                                                            <option value="hupp">100 per program</option>
                                                                            <option value="fipp">50 per program</option>
                                                                            <option value="twfy">250</option>
                                                                            <option value="twpf">250 & Proportional for lesser</option>
                                                                            <option value="fipe">50 per program</option>
                                                                            <option value="fipr">50 per program</option>
                                                                            <option value="fpro">10 per program</option>
                                                                            <option value="hundr">100</option>
                                                                            <option value="fept">50</option>
                                                                            <option value="fetp">50</option>

                                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Self - Appraisal Score</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="sea1"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sassid2; ?>" id="sassid2">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="forme2()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <p class="card-description">
                                            <u>Consolidated Marks of All Categories:</u>
                                            <p style=" Text-align:right; color: white; margin-top: -1cm;"><a
                                                class="btn btn-success" id="Coshow">Add</a></p>
                                        </p>
                                        <table width="100%">
                                            <thead>
                                             <th colspan="2" width="40%">Max Total Marks For All Categories</th>
                                             <th>Total Employee Self Appraisal Score</th>
                                             <th>Average Score of all Concerned after Verification</th>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Acedemics</td>
                                                    <td>300M</td>

                                                </tr>
                                                <tr>
                                                    <td>R&D</td>
                                                    <td>150M</td>
                                                    
                                                </tr><tr>
                                                    <td>ADMINISTRATION</td>
                                                    <td>150M</td>
                                                    
                                                </tr>
                                                <tr>
                                                    <td>Extension</td>
                                                    <td>150M</td>
                                                    
                                                </tr><tr>
                                                    <td>Selected AREA of CHOICE <br> ___________</td>
                                                    <td>250M</td>
                                                    
                                                </tr><tr>
                                                    <td>Grand Total</td>
                                                    
                                                </tr><tr>
                                                    <td colspan="2">Faculty Sign:<br><br><br><br></td>
                                                    <td>Sign of Deputy HOD(s)<br><br><br>
                                                    Name:<br><br><br><br><br></td>
                                                    
                                                
                                                    <td>Sign of HOD<br><br><br><br><br> 
                                                    Name:<br><br><br><br><br><br></td>
                                                    
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br>
                                        <hr>
                                        <div id="Codiv">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Max Total Marks For All Categories</label>
                                                        <div class="col-sm-9">
                                                        <select class="form-control form-control-lg" id="smtm">
                                                                <option selected hidden value="" >Select Max Total Marks For All Categories</option>
                                                                <option value="acad">Acedemics --> 300M</option>
                                                                <option value="rand">R&D --> 150M</option>
                                                                <option value="admi">ADMINISTRATION --> 150M</option>
                                                                <option value="exte">Extension --> 150M</option>
                                                                <option value="saoc">Selected AREA of CHOICE --> 250M</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Total Employee Self Appraisal Score</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="tesa"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">	Average Score of all Concerned after Verification</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="asoa"/> 
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Faculty Sign:</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="facs"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Sign of Deputy HOD(s)
                                                         Name:
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="sodh"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group row">
                                                        <label class="col-sm-3 col-form-label">Sign of HOD
                                                        Name:
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control" id="sohod"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                                <div class="form-group row">
                                                                    <input type="hidden" value="<?php echo $sassid3; ?>" id="sassid3">
                                                                    <button style="color: white;" class="btn btn-primary" onclick="forme3()" id="hide">Insert</button>
                                                                </div>
                                                            </div>
                                        </div>
                                        <br>



                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <a
                                href="" target="_blank">Project Expo.com </a>2022</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <script>
        $(document).ready(function () {

            $("#Pashow").click(function () {
                $("#Padiv").toggle();
            });
            $("#Opshow").click(function () {
                $("#Opdiv").toggle();
            });
            $("#Coshow").click(function () {
                $("#Codiv").toggle();
            });
        });
    </script>
    <script>
        function allhide() {


            document.getElementById('Padiv').style.display = "none";
            document.getElementById('Opdiv').style.display = "none";
            document.getElementById('Codiv').style.display = "none";
        }
    </script>
     <!-- plugins:js -->
     <script src="vendors/base/vendor.bundle.base.js"></script>
     <!-- endinject -->
     <!-- Plugin js for this page-->
     <script src="vendors/chart.js/Chart.min.js"></script>
     <script src="vendors/datatables.net/jquery.dataTables.js"></script>
     <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
     <!-- End plugin js for this page-->
     <!-- inject:js -->
     <script src="js/off-canvas.js"></script>
     <script src="js/hoverable-collapse.js"></script>
     <script src="js/template.js"></script>
     <!-- endinject -->
     <!-- Custom js for this page-->
     <script src="js/dashboard.js"></script>
     <script src="js/data-table.js"></script>
     <script src="js/jquery.dataTables.js"></script>
     <script src="js/dataTables.bootstrap4.js"></script>
     <!-- End custom js for this page-->
 
     <script src="js/jquery.cookie.js" type="text/javascript"></script>
</body>

</html>