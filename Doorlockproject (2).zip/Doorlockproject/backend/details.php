<?php
$get_cid=$_GET["Empid"];
?>