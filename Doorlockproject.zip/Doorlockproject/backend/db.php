<?php
$server = "localhost";
$username = "root";
$password = "tiger";
$dbname = "doorproject";
$connection = mysqli_connect($server, $username, $password, $dbname);
