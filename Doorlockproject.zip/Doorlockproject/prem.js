var z=100
var x=80
var y=90
console.log(z++ +x +--y)