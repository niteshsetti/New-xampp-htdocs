const che=(tabno)=>{
    window.location.href="../frontend/fetch.php?%20tab="+tabno;
}